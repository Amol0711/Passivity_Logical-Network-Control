# GitHub upload instructions — simulation release v2.0.2

This deliverable contains two repository forms:

- `bn_passivity_automatica_repro-2.0.2.bundle` preserves the existing Git history and tags and is the recommended upload source.
- `bn_passivity_automatica_repro-2.0.2.zip` and `.tar.gz` are clean source snapshots without `.git` metadata.

Release commit:

```text
9bcdcc9471f29efc9be08f6c1bb68cba89a9c3ec
```

Release tag:

```text
v2.0.2
```

## Recommended: push from the Git bundle

```bash
git clone bn_passivity_automatica_repro-2.0.2.bundle bn_passivity_automatica_repro
cd bn_passivity_automatica_repro
git remote remove origin
git remote add origin https://github.com/Amol0711/bn_passivity_automatica_repro.git
git push origin master --tags
```

The push is a fast-forward from the packaged v2.0.1 history. If the GitHub repository uses `main` rather than `master`, use:

```bash
git push origin master:main --tags
```

## Alternative: upload the clean source snapshot

Extract `bn_passivity_automatica_repro-2.0.2.zip`. The extracted directory contains only repository source and data files. It does not contain Git history. To create a new repository history from the snapshot:

```bash
cd bn_passivity_automatica_repro-2.0.2
git init
git add .
git commit -m "Simulation reproducibility release 2.0.2"
git branch -M main
git remote add origin https://github.com/Amol0711/bn_passivity_automatica_repro.git
git push -u origin main
```

The bundle route is preferred because it retains v2.0.0, v2.0.1, and v2.0.2 history and tags.

## Post-upload verification

From a fresh public clone, run:

```bash
sha256sum -c SHA256SUMS.txt
bash scripts/reproduce_all.sh
```

The second command should return a JSON object with `"pass": true` and eight passing components.
