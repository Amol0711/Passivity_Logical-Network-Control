# Simulation reproducibility package for finite-alphabet dissipativity certificates

This repository contains simulation, model, certificate, and validation artifacts for the paper:

**Compositional Finite-Alphabet Dissipativity Certificates for Logical Network Control**

Release version: **1.0**  
Date: 2026-07-08

This repository is intentionally limited to computational reproducibility artifacts. It does not include paper source files, paper PDFs, bibliography files, or LaTeX/TikZ figure sources.

## What is included

```text
configs/       Candidate and clamp-configuration files for optional solver reruns.
data/          Frozen GZMB/MCL1 projected-certificate tables.
model/         T-LGL Boolean-network model record and model-partition metadata.
results/       Reference outputs, solver summaries, and case-study claim ledgers.
scripts/       Verification, solver rerun, and release-check scripts.
tests/         Static package and claim-integrity checks.
docs/          Reproducibility-scope and release-check notes.
```

The package includes executable checks for the main GZMB/MCL1 projected certificate, the projection-free compensation-chain benchmark, and a bounded-treewidth scaled-linear-programming search family. It also includes frozen reference summaries and optional solver-rerun scripts for the promoted TPL2/S1P gate and related candidate-screening workflow.

## Quick start

Use Python 3.10 or newer. The quick release check uses SciPy for the bounded-treewidth LP-scaling smoke rerun.

```bash
python3 --version
bash scripts/reproduce_all.sh
```

Expected result: the script prints a JSON object with `"pass": true`.

The quick command checks shipped reference files, reruns the standard-library GZMB/MCL1 certificate verifier, reruns the projection-free chain benchmark, reruns a small bounded-treewidth scaled-LP search instance, validates the promoted TPL2/S1P reference summary, and checks the case-study simulation claim ledger.

## Environment

The GZMB/MCL1 and chain verifiers use the Python standard library. The bounded-treewidth LP-scaling check and optional LP reruns require SciPy. Candidate-screening workflows also require SymPy:

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt
```

A conda environment file is also provided:

```bash
conda env create -f environment.yml
conda activate bn-passivity-automatica-repro
```

## Reproducing the main computational rows

| Paper row | Primary command | Expected output |
|---|---|---|
| GZMB/MCL1 projected certificate | `python3 scripts/verify_gzmb_mcl1_certificate.py --data data --outdir results/rerun/gzmb_mcl1` | pass, 54-variable model, `2^54` fixed-input state count, 48 local edges, 64 port rows, `T_star <= 7`, exact projected maximum 5 |
| TPL2/S1P promoted gate | `python3 scripts/verify_release_claims.py` | pass, reference summary has 4,233 variables, 135,490 inequalities, 131,072 port rows, `T_star <= 8`, exact projected maximum 7 |
| Projection-free chain | `python3 scripts/verify_compensation_chain.py --outdir results/rerun/chain --reference results/reference/chain_benchmark/compensation_chain_summary.json` | pass for `K=4,16,64,256`, up to `2^1280`, with `T_star <= 5K^2` |
| Bounded-treewidth LP-search scaling | `python3 scripts/reproduce_lp_scaling_family.py --ks 8,16,32,64,128,256,512 --outdir results/rerun/lp_scaling_family --reference results/reference/lp_scaling_family/lp_scaling_family_summary.json` | pass for `K=8,...,512`, up to `2^2560`, with `36K+1` LP variables, `K+1` generated cuts, and `T_star <= K` |
| DISC, cascade, three-bit, and reduced T-LGL audit rows | `python3 scripts/verify_release_claims.py` | pass against the simulation ledger in `results/reference/case_study_claims/case_study_claims.json` |

The full T-LGL state graph is never enumerated in the main T-LGL rows. The full-model step is a source-rule closure/projection or lifting audit. The finite LP certificates are checked on projected local edge covers and finite port covers.

## Optional heavier reruns

The original solver workflows are preserved for reviewers who want to rerun more than the quick frozen/reference checks.

```bash
# Rerun the GZMB/MCL1 LP and candidate-screening workflow.
bash scripts/reproduce_solver_workflow.sh results/rerun/solver_workflow

# Rerun the multi-module LP generator for all configured candidates.
bash scripts/reproduce_multimodule_lp.sh results/rerun/multimodule_lp

# Rerun the TPL2/S1P promotion decision using multi-module reference outputs.
bash scripts/reproduce_tpl2_s1p_promotion.sh results/rerun/tpl2_s1p_promotion
```

The multi-module LP rerun is the heaviest biological workflow. The bounded-treewidth LP-scaling script is controlled and synthetic. The quick release check reruns a small LP-scaling subset and validates the full shipped summary.

## Integrity checks

From the repository root:

```bash
sha256sum -c SHA256SUMS.txt
```

Generated files under `results/rerun/` are intentionally excluded from the manifest and hashes.

## Claim ledger

See [`CLAIMS.md`](CLAIMS.md) for a paper-claim-to-artifact map. The machine-readable simulation claim ledger is:

```text
results/reference/case_study_claims/case_study_claims.json
```

## Model provenance

The T-LGL model record is documented in [`MODEL_PROVENANCE.md`](MODEL_PROVENANCE.md). This repository is a simulation reproducibility package. Biological variables and interventions are logical-model certificate demonstrations and are not therapeutic claims.

## Recommended GitHub release procedure

1. Push this directory to the GitHub repository.
2. Run `bash scripts/reproduce_all.sh` from a clean clone.
3. Run `sha256sum -c SHA256SUMS.txt`.
4. Tag a release, for example `v1.0.0`.
5. Optionally archive that release on Zenodo and use the release DOI in the paper.
