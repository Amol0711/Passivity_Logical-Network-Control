#!/usr/bin/env python3
"""Fast static smoke checks for the simulation-only GitHub reproducibility package."""
from __future__ import annotations
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def check_required_paths() -> None:
    required = [
        'README.md', 'CLAIMS.md', 'CITATION.cff', 'LICENSE', 'DATA_LICENSE_NOTICE.md',
        'MODEL_PROVENANCE.md', 'Makefile', 'SHA256SUMS.txt', 'MANIFEST.tsv',
        'data/certificate_summary.json', 'model/tlgl_2011_survival_network.bnet',
        'results/reference/multimodule_lp/tpl2_s1p_projected_gate/candidate_summary.json',
        'results/reference/chain_benchmark/compensation_chain_summary.json',
        'results/reference/lp_scaling_family/lp_scaling_family_summary.json',
        'results/reference/case_study_claims/case_study_claims.json',
        'scripts/verify_release_claims.py', 'scripts/reproduce_lp_scaling_family.py', 'scripts/reproduce_all.sh',
    ]
    missing = [p for p in required if not (ROOT / p).exists()]
    if missing:
        raise AssertionError('missing required paths: ' + ', '.join(missing))


def check_no_paper_artifacts() -> None:
    forbidden_dirs = ['paper_source', 'figures']
    present = [p for p in forbidden_dirs if (ROOT / p).exists()]
    if present:
        raise AssertionError('forbidden paper/figure directories present: ' + ', '.join(present))
    forbidden_suffixes = {'.pdf', '.bib'}
    forbidden_tex = []
    for path in ROOT.rglob('*'):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        if path.suffix in forbidden_suffixes or (path.suffix == '.tex' and not rel.startswith('scripts/')):
            forbidden_tex.append(rel)
    if forbidden_tex:
        raise AssertionError('forbidden paper-build files present: ' + ', '.join(forbidden_tex[:20]))


def check_manifest() -> None:
    proc = subprocess.run(['sha256sum', '-c', 'SHA256SUMS.txt'], cwd=ROOT, text=True, capture_output=True)
    if proc.returncode != 0:
        raise AssertionError('SHA256SUMS check failed\n' + proc.stdout + proc.stderr)


def check_static_claims() -> None:
    proc = subprocess.run([
        sys.executable, str(ROOT / 'scripts' / 'verify_release_claims.py'), '--skip-executable'
    ], cwd=ROOT, text=True, capture_output=True)
    if proc.returncode != 0:
        raise AssertionError('static claim check failed\n' + proc.stdout + proc.stderr)
    data = json.loads(proc.stdout)
    if not data.get('pass'):
        raise AssertionError('static claim check reported pass=false')


def main() -> int:
    checks = [check_required_paths, check_no_paper_artifacts, check_manifest, check_static_claims]
    for fn in checks:
        fn()
        print(f'PASS {fn.__name__}')
    print('SMOKE_CHECK_PASS')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
