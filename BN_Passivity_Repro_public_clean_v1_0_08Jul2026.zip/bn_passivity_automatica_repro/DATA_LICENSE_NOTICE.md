# Data license and reuse notice

The code in this repository is distributed under the MIT license in `LICENSE`.

The bundled T-LGL BNET model record is included for research reproducibility of the computational certificate checks. Please cite the original T-LGL logical-network sources named in `MODEL_PROVENANCE.md` when using or redistributing the model record.

The repository contains simulation and certificate artifacts only. It does not contain paper source files, paper PDFs, bibliography files, or LaTeX/TikZ figure sources.
