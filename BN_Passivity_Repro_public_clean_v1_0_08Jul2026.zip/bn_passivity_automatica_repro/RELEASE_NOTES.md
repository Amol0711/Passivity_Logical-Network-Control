# Release notes for version 1.0

This release contains the simulation and certificate-reproduction artifacts for the associated paper.

## Included

- T-LGL Boolean-network model record and provenance notes.
- GZMB/MCL1 projected-certificate tables and executable verifier.
- Promoted TPL2/S1P gate reference summaries and optional multi-module solver workflow.
- Projection-free compensation-chain benchmark.
- Bounded-treewidth LP-search scaling family.
- Case-study simulation claim ledger for DISC, cascade, three-bit, and reduced T-LGL audit rows.
- Static smoke tests, release checker, manifest, and SHA-256 checksums.

## Excluded

- Paper source files.
- Paper PDFs.
- Bibliography files.
- LaTeX/TikZ figure sources.
- Generated rerun outputs under `results/rerun/`.

## Recommended release checklist

- Run `bash scripts/reproduce_all.sh` from a clean clone.
- Run `sha256sum -c SHA256SUMS.txt`.
- Confirm that the repository contains no paper build artifacts.
- Create a release tag, preferably `v1.0.0`.
