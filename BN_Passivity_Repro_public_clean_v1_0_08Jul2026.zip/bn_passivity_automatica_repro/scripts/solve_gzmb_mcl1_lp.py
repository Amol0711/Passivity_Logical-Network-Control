#!/usr/bin/env python3
"""Solve and export the GZMB/MCL1 projected-kernel LP certificate.

The script uses the bundled 54-target T-LGL BNET file only to audit the five
projected rules used by the certificate. It does not enumerate the 2^54 full
state graph. The LP itself is the two-module execution/survival kernel LP used
in the associated paper.

Default paths are relative to this script:
  model/tlgl_2011_survival_network.bnet
  results/rerun/solve/ or a user-specified --outdir
"""
from __future__ import annotations

import argparse
import ast
import csv
import json
import math
import re
from itertools import product
from pathlib import Path
from time import perf_counter
from typing import Dict, Iterable, Mapping, Tuple

try:
    from scipy.optimize import linprog
except Exception as exc:  # pragma: no cover
    raise SystemExit("scipy is required for solve_gzmb_mcl1_lp.py; use verify_gzmb_mcl1_certificate.py for a no-scipy certificate check") from exc

NAME_TOKEN = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*\b")
KEYWORDS = {"and", "or", "not", "True", "False"}


def normalize_expr(expr: str) -> str:
    return expr.replace("!", " not ").replace("&", " and ").replace("|", " or ").strip()


def eval_bool(expr: str, env: Mapping[str, int | bool]) -> int:
    parsed = ast.parse(normalize_expr(expr), mode="eval")
    return int(bool(eval(compile(parsed, "<bnet>", "eval"), {"__builtins__": {}}, {k: bool(v) for k, v in env.items()})))


def parse_bnet(path: Path) -> Dict[str, str]:
    rules: Dict[str, str] = {}
    with path.open("r", encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.lower().replace(" ", "") in {"targets,factors", "target,factor"}:
                continue
            lhs, rhs = (part.strip() for part in line.split(",", 1))
            rules[lhs] = rhs
    if not rules:
        raise RuntimeError(f"no rules found in {path}")
    return rules


def dependency_tokens(expr: str) -> list[str]:
    return sorted({tok for tok in NAME_TOKEN.findall(expr) if tok not in KEYWORDS})


def combo_kernel_next(A: int, C: int, B: int, I: int, L: int, N: int, D: int) -> Tuple[int, int, int, int, int]:
    # A=Apoptosis, C=Caspase, B=BID, I=IAP, L=BclxL, N=NFKB, D=DISC.
    Ap = int(A or C)
    Cp = int(D or (B and not I)) if A == 0 else int(A or C)
    Bp = int((not L) and (not A))
    Ip = int(N and not (B or A))
    Lp = 0 if A == 0 else 0
    return Ap, Cp, Bp, Ip, Lp


def exact_kernel_hitting_times() -> Dict[Tuple[int, int, int, int, int], int]:
    states = list(product((0, 1), repeat=5))
    H: Dict[Tuple[int, int, int, int, int], int | None] = {tuple(s): (0 if s[0] == 1 else None) for s in states}
    changed = True
    while changed:
        changed = False
        for s in states:
            s = tuple(s)
            if H[s] is not None:
                continue
            succ = {combo_kernel_next(*s, N, D) for N, D in product((0, 1), repeat=2)}
            if all(H[sp] is not None for sp in succ):
                H[s] = 1 + max(int(H[sp]) for sp in succ)
                changed = True
    missing = [s for s, v in H.items() if v is None]
    if missing:
        raise RuntimeError(f"kernel has non-reaching states: {missing[:5]}")
    return {s: int(v) for s, v in H.items()}


def build_combo_lp() -> dict:
    states_E = list(product((0, 1), repeat=3))  # A,C,BID
    states_S = list(product((0, 1), repeat=2))  # IAP,BclxL
    sigma_E_keys = list(product(states_E, (0, 1), (0, 1), (0, 1)))  # zE,I,L,D
    sigma_S_keys = list(product(states_S, (0, 1), (0, 1), (0, 1)))  # zS,A,B,N

    idx: Dict[Tuple[object, ...], int] = {}
    n = 0
    for s in states_E:
        idx[("VE",) + tuple(s)] = n; n += 1
    for s in states_S:
        idx[("VS",) + tuple(s)] = n; n += 1
    for zE, I, L, D in sigma_E_keys:
        idx[("SE",) + tuple(zE) + (I, L, D)] = n; n += 1
    for zS, A, B, N in sigma_S_keys:
        idx[("SS",) + tuple(zS) + (A, B, N)] = n; n += 1
    bmax_idx = n; n += 1

    rows: list[list[float]] = []
    rhs: list[float] = []

    def add(terms: Iterable[Tuple[Tuple[object, ...] | str, float]], bound: float) -> None:
        row = [0.0] * n
        for key, val in terms:
            if key == "BMAX":
                row[bmax_idx] += val
            else:
                row[idx[tuple(key)]] += val
        rows.append(row); rhs.append(bound)

    # Execution local inequalities: Delta V_E <= sigma_E.
    for A, C, B in states_E:
        if A == 1:
            continue
        for I, L, D in product((0, 1), repeat=3):
            Ap, Cp, Bp, _Ip, _Lp = combo_kernel_next(A, C, B, I, L, 0, D)
            add([(("VE", Ap, Cp, Bp), 1.0), (("VE", A, C, B), -1.0), (("SE", A, C, B, I, L, D), -1.0)], 0.0)

    # Survival local inequalities: Delta V_S <= sigma_S.
    for I, L in states_S:
        for A, B, N in product((0, 1), repeat=3):
            if A == 1:
                continue
            _Ap, _Cp, _Bp, Ip, Lp = combo_kernel_next(A, 0, B, I, L, N, 0)
            add([(("VS", Ip, Lp), 1.0), (("VS", I, L), -1.0), (("SS", I, L, A, B, N), -1.0)], 0.0)

    # Port interconnection inequality: sigma_E + sigma_S <= -1 outside target.
    for A, C, B, I, L, N, D in product((0, 1), repeat=7):
        if A == 1:
            continue
        add([(("SE", A, C, B, I, L, D), 1.0), (("SS", I, L, A, B, N), 1.0)], -1.0)

    # Objective variable bounds the additive storage outside target.
    for A, C, B, I, L in product((0, 1), repeat=5):
        if A == 1:
            continue
        add([(("VE", A, C, B), 1.0), (("VS", I, L), 1.0), ("BMAX", -1.0)], 0.0)

    storage_vars = len(states_E) + len(states_S)
    supply_vars = len(sigma_E_keys) + len(sigma_S_keys)
    bounds = [(0.0, None)] * storage_vars + [(None, None)] * supply_vars + [(0.0, None)]
    c = [0.0] * n; c[bmax_idx] = 1.0
    t0 = perf_counter()
    res = linprog(c, A_ub=rows, b_ub=rhs, bounds=bounds, method="highs")
    solve_seconds = perf_counter() - t0
    if not res.success:
        raise RuntimeError(str(res.message))
    x = res.x

    VE = {(A, C, B): float(x[idx[("VE", A, C, B)]]) for A, C, B in states_E}
    VS = {(I, L): float(x[idx[("VS", I, L)]]) for I, L in states_S}
    SE = {(A, C, B, I, L, D): float(x[idx[("SE", A, C, B, I, L, D)]]) for (A, C, B), I, L, D in sigma_E_keys}
    SS = {(I, L, A, B, N): float(x[idx[("SS", I, L, A, B, N)]]) for (I, L), A, B, N in sigma_S_keys}

    port_rows = []
    tight = pos_E = pos_S = comp = 0
    min_slack = math.inf; max_slack = -math.inf
    for A, C, B, I, L, N, D in product((0, 1), repeat=7):
        if A == 1:
            continue
        se = SE[(A, C, B, I, L, D)]
        ss = SS[(I, L, A, B, N)]
        sigma_sum = se + ss
        slack = -1.0 - sigma_sum
        is_tight = abs(slack) <= 1e-8
        is_comp = (se > 1e-8 and ss < -1.0 - 1e-8) or (ss > 1e-8 and se < -1.0 - 1e-8)
        tight += int(is_tight); pos_E += int(se > 1e-8); pos_S += int(ss > 1e-8); comp += int(is_comp)
        min_slack = min(min_slack, slack); max_slack = max(max_slack, slack)
        port_rows.append({"A": A, "C": C, "BID": B, "IAP": I, "BclxL": L, "NFKB": N, "DISC": D,
                          "sigma_execution": se, "sigma_survival": ss, "sigma_sum": sigma_sum,
                          "required_upper_bound": -1.0, "port_slack": slack,
                          "tight": int(is_tight), "compensated_positive_supply": int(is_comp)})

    execution_edges = []
    for A, C, B in states_E:
        if A == 1:
            continue
        for I, L, D in product((0, 1), repeat=3):
            Ap, Cp, Bp, _Ip, _Lp = combo_kernel_next(A, C, B, I, L, 0, D)
            dv = VE[(Ap, Cp, Bp)] - VE[(A, C, B)]
            se = SE[(A, C, B, I, L, D)]
            execution_edges.append({"A": A, "C": C, "BID": B, "IAP_port": I, "BclxL_port": L, "DISC_port": D,
                                    "A_next": Ap, "C_next": Cp, "BID_next": Bp,
                                    "delta_storage": dv, "sigma_execution": se, "local_slack": se - dv})
    survival_edges = []
    for I, L in states_S:
        for A, B, N in product((0, 1), repeat=3):
            if A == 1:
                continue
            _Ap, _Cp, _Bp, Ip, Lp = combo_kernel_next(A, 0, B, I, L, N, 0)
            dv = VS[(Ip, Lp)] - VS[(I, L)]
            ss = SS[(I, L, A, B, N)]
            survival_edges.append({"IAP": I, "BclxL": L, "A_port": A, "BID_port": B, "NFKB_port": N,
                                   "IAP_next": Ip, "BclxL_next": Lp,
                                   "delta_storage": dv, "sigma_survival": ss, "local_slack": ss - dv})

    return {
        "objective_bound": float(res.fun),
        "status": str(res.message),
        "solve_seconds": solve_seconds,
        "variable_count": n,
        "inequality_count": len(rows),
        "storage_variable_count": storage_vars,
        "supply_variable_count": supply_vars,
        "local_edge_count": len(execution_edges) + len(survival_edges),
        "execution_edge_count": len(execution_edges),
        "survival_edge_count": len(survival_edges),
        "port_cover_count": len(port_rows),
        "bound_inequality_count": 16,
        "tight_port_count": tight,
        "positive_execution_supply_ports": pos_E,
        "positive_survival_supply_ports": pos_S,
        "compensated_positive_supply_ports": comp,
        "min_port_slack": float(min_slack),
        "max_port_slack": float(max_slack),
        "storage_execution": {f"A{A}C{C}B{B}": VE[(A,C,B)] for A,C,B in states_E},
        "storage_survival": {f"I{I}L{L}": VS[(I,L)] for I,L in states_S},
        "port_rows": port_rows,
        "execution_edges": execution_edges,
        "survival_edges": survival_edges,
    }


def check_rule_implications(rules: Mapping[str, str]) -> list[dict]:
    checks = [
        ("Apoptosis_plus_equals_A_or_C_absorbing", "v_Apoptosis"),
        ("BID_plus_equals_not_BclxL_under_GZMB_ON_MCL1_OFF_A0", "v_BID"),
        ("Caspase_plus_equals_DISC_or_BID_not_IAP_under_GZMB_ON_A0", "v_Caspase"),
        ("BclxL_plus_zero_under_GZMB_ON_A0", "v_BclxL"),
        ("IAP_plus_equals_NFKB_not_BID_under_A0", "v_IAP"),
    ]
    ok = {name: True for name, _ in checks}
    for A, C, B, I, L, N, D, T, S in product((0, 1), repeat=9):
        env = {name: 0 for name in rules}
        env.update({"v_Apoptosis": A, "v_Caspase": C, "v_BID": B, "v_IAP": I, "v_BclxL": L,
                    "v_NFKB": N, "v_DISC": D, "v_TRADD": T, "v_STAT3": S, "v_GZMB": 1, "v_MCL1": 0})
        if eval_bool(rules["v_Apoptosis"], env) != int(A or C): ok["Apoptosis_plus_equals_A_or_C_absorbing"] = False
        if A == 0:
            if eval_bool(rules["v_BID"], env) != int(not L): ok["BID_plus_equals_not_BclxL_under_GZMB_ON_MCL1_OFF_A0"] = False
            if eval_bool(rules["v_Caspase"], env) != int(D or (B and not I)): ok["Caspase_plus_equals_DISC_or_BID_not_IAP_under_GZMB_ON_A0"] = False
            if eval_bool(rules["v_BclxL"], env) != 0: ok["BclxL_plus_zero_under_GZMB_ON_A0"] = False
            if eval_bool(rules["v_IAP"], env) != int(N and not B): ok["IAP_plus_equals_NFKB_not_BID_under_A0"] = False
    return [{"check": name, "source_rule": rule, "pass": int(ok[name])} for name, rule in checks]


def primary_failure_witness(rules: Mapping[str, str]) -> dict:
    env = {name: 0 for name in rules}
    env.update({"v_Apoptosis": 0, "v_Caspase": 0, "v_BID": 0, "v_BclxL": 0, "v_MCL1": 1,
                "v_IAP": 0, "v_DISC": 0, "v_GZMB": 1, "v_IL2RB": 1, "v_PI3K": 1,
                "v_NFKB": 1, "v_STAT3": 1})
    return {
        "candidate": "GZMB=ON, IAP=OFF",
        "blocking_assignment": env,
        "next_values_before_IAP_reclamp": {
            "v_Apoptosis_plus": eval_bool(rules["v_Apoptosis"], env),
            "v_Caspase_plus": eval_bool(rules["v_Caspase"], env),
            "v_BID_plus": eval_bool(rules["v_BID"], env),
            "v_BclxL_plus": eval_bool(rules["v_BclxL"], env),
            "v_MCL1_plus": eval_bool(rules["v_MCL1"], env),
        },
        "interpretation": "With MCL1=ON sustained by survival ports and DISC=OFF, BID and Caspase do not advance; MCL1=OFF repairs this obstruction while leaving IAP dynamic.",
    }


def write_csv(path: Path, rows: Iterable[Mapping[str, object]]) -> None:
    rows = list(rows)
    keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.DictWriter(fh, fieldnames=keys)
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    default_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument("--bnet", type=Path, default=default_root / "model" / "tlgl_2011_survival_network.bnet")
    parser.add_argument("--outdir", type=Path, default=default_root / "results" / "rerun" / "solve")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    rules = parse_bnet(args.bnet)
    external = sorted({tok for expr in rules.values() for tok in NAME_TOKEN.findall(expr) if tok not in rules and tok not in KEYWORDS})
    lp = build_combo_lp()
    H = exact_kernel_hitting_times()
    checks = check_rule_implications(rules)

    summary = {
        "pass_status": bool(all(row["pass"] for row in checks) and lp["objective_bound"] == 7.0),
        "intervention": "GZMB=ON, MCL1=OFF outside Apoptosis=ON",
        "model_variables": len(rules),
        "model_external_inputs": len(external),
        "external_inputs": external,
        "full_fixed_input_state_count": 2 ** len(rules),
        "full_component_input_valuation_count": 2 ** (len(rules) + len(external)),
        "kernel_state_count": len(H),
        "exact_kernel_max_hitting_time": max(H.values()),
        "lp_summary": {k: v for k, v in lp.items() if k not in {"port_rows", "execution_edges", "survival_edges", "solve_seconds"}},
        "rule_implication_checks": checks,
        "failed_primary_candidate": primary_failure_witness(rules),
    }

    write_csv(args.outdir / "storage_values.csv", [{"module": "execution", "state": k, "storage": v} for k, v in lp["storage_execution"].items()] + [{"module": "survival", "state": k, "storage": v} for k, v in lp["storage_survival"].items()])
    write_csv(args.outdir / "all_port_inequalities.csv", lp["port_rows"])
    write_csv(args.outdir / "compensated_positive_supply_ports.csv", [r for r in lp["port_rows"] if r["compensated_positive_supply"]])
    write_csv(args.outdir / "execution_local_edges.csv", lp["execution_edges"])
    write_csv(args.outdir / "survival_local_edges.csv", lp["survival_edges"])
    write_csv(args.outdir / "kernel_hitting_times.csv", [{"A": s[0], "C": s[1], "BID": s[2], "IAP": s[3], "BclxL": s[4], "H_kernel": h} for s, h in sorted(H.items())])
    write_csv(args.outdir / "rule_implication_checks.csv", checks)
    write_csv(args.outdir / "rule_dependencies.csv", [{"node": name, "dependencies": ";".join(dependency_tokens(rules[name]))} for name in ["v_Apoptosis", "v_Caspase", "v_BID", "v_IAP", "v_BclxL"]])
    (args.outdir / "certificate_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    (args.outdir / "primary_failure_witness.json").write_text(json.dumps(summary["failed_primary_candidate"], indent=2, sort_keys=True), encoding="utf-8")

    print(json.dumps({
        "pass": summary["pass_status"], "bound": lp["objective_bound"], "kernel_exact_max": max(H.values()),
        "variables": lp["variable_count"], "inequalities": lp["inequality_count"], "local_edges": lp["local_edge_count"],
        "port_cover": lp["port_cover_count"], "compensated_ports": lp["compensated_positive_supply_ports"],
        "outdir": str(args.outdir), "solve_seconds": lp["solve_seconds"]
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
