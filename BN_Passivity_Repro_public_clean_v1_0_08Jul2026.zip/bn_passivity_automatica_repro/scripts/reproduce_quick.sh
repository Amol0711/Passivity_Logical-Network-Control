#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
python3 "$ROOT/scripts/verify_release_claims.py" --outdir "$ROOT/results/rerun/quick_release"
