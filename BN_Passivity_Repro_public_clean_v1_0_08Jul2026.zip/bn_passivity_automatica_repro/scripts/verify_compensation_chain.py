#!/usr/bin/env python3
"""Verify the projection-free compensation-chain benchmark.

The benchmark has K five-bit units. Unit i exposes only its completion flag
c_i = 1{all five local bits are one}. With c_0=1, the closed-loop update is
    z_i^+ = 11111  if c_{i-1}=1,
    z_i^+ = z_i    if c_{i-1}=0.
No coordinate projection is used: each unit state is the full 5-bit local state.
The storage and supply certificate are
    V_i(z_i) = K * number_of_zero_bits(z_i),
    sigma_i(c_{i-1},c_i) = 0   if c_i=1,
                            -K  if c_i=0 and c_{i-1}=1,
                            +1  if c_i=0 and c_{i-1}=0.
The port inequality is sum_i sigma_i + 1_{not all c_i=1} <= 0.
"""
from __future__ import annotations

import argparse
import csv
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Tuple

BITS_PER_UNIT = 5
FULL_STATE = (1 << BITS_PER_UNIT) - 1


def popcount(x: int) -> int:
    return int(x.bit_count())


def complete(z: int) -> int:
    return int(z == FULL_STATE)


def storage(k: int, z: int) -> int:
    return k * (BITS_PER_UNIT - popcount(z))


def sigma(k: int, prev_complete: int, curr_complete: int) -> int:
    if curr_complete:
        return 0
    return -k if prev_complete else 1


def successor(z: int, prev_complete: int) -> int:
    return FULL_STATE if prev_complete else z


@dataclass
class ChainSummary:
    K: int
    local_bits: int
    product_states: str
    modules: int
    storage_variables: int
    local_edge_rows: int
    brute_force_port_rows: str
    dp_factor_count: int
    dp_treewidth: int
    max_local_residual: int
    max_port_expression: int
    alpha_min: int
    certified_bound: int
    exact_parallel_bound: int
    nonprojection: bool
    positive_supply_witness: str
    pass_: bool

    def csv_row(self) -> Dict[str, object]:
        d = asdict(self)
        d["pass"] = d.pop("pass_")
        return d


def verify_local(k: int) -> int:
    """Return max(V^+ - V - sigma) over all local rows."""
    max_residual = -10**9
    for i in range(1, k + 1):
        prev_values = [1] if i == 1 else [0, 1]
        for prev in prev_values:
            for z in range(1 << BITS_PER_UNIT):
                c = complete(z)
                zp = successor(z, prev)
                residual = storage(k, zp) - storage(k, z) - sigma(k, prev, c)
                max_residual = max(max_residual, residual)
    return max_residual


def port_dp(k: int) -> Tuple[int, List[int]]:
    """Maximize sum sigma + alpha by path dynamic programming."""
    current: Dict[Tuple[int, int], Tuple[int, Tuple[int, int] | None, int | None]] = {(1, 1): (0, None, None)}
    layers: List[Dict[Tuple[int, int], Tuple[int, Tuple[int, int] | None, int | None]]] = []
    for _i in range(1, k + 1):
        nxt: Dict[Tuple[int, int], Tuple[int, Tuple[int, int] | None, int | None]] = {}
        for (prev_c, all_prev), (value, _pred, _chosen) in current.items():
            for c in (0, 1):
                all_now = int(all_prev and c == 1)
                key = (c, all_now)
                cand = value + sigma(k, prev_c, c)
                if key not in nxt or cand > nxt[key][0]:
                    nxt[key] = (cand, (prev_c, all_prev), c)
        layers.append(nxt)
        current = nxt
    best_key = None
    best_val = -10**9
    for key, (value, _pred, _chosen) in current.items():
        all_complete = key[1]
        cand = value + (0 if all_complete else 1)
        if cand > best_val:
            best_val = cand
            best_key = key
    assert best_key is not None

    witness_rev: List[int] = []
    key = best_key
    for layer in reversed(layers):
        _value, pred, chosen = layer[key]
        assert chosen is not None and pred is not None
        witness_rev.append(chosen)
        key = pred
    witness = list(reversed(witness_rev))
    return best_val, witness


def non_target_positive_witness(k: int) -> Tuple[str, int]:
    return f"all c_i=0; sigma_1=-{k}, sigma_2..sigma_K=+1; sum_plus_alpha=0", 0


def summarize(k: int) -> ChainSummary:
    max_local = verify_local(k)
    max_port, _witness = port_dp(k)
    witness, val_w = non_target_positive_witness(k)
    local_edge_rows = (1 << BITS_PER_UNIT) + (k - 1) * 2 * (1 << BITS_PER_UNIT)
    certified_bound = BITS_PER_UNIT * k * k
    exact_bound = k
    passed = (max_local <= 0 and max_port <= 0 and val_w == 0)
    return ChainSummary(
        K=k,
        local_bits=BITS_PER_UNIT * k,
        product_states=f"2^{BITS_PER_UNIT * k}",
        modules=k,
        storage_variables=(1 << BITS_PER_UNIT) * k,
        local_edge_rows=local_edge_rows,
        brute_force_port_rows=f"2^{k}",
        dp_factor_count=k,
        dp_treewidth=1,
        max_local_residual=max_local,
        max_port_expression=max_port,
        alpha_min=1,
        certified_bound=certified_bound,
        exact_parallel_bound=exact_bound,
        nonprojection=True,
        positive_supply_witness=witness,
        pass_=passed,
    )


def parse_ks(value: str) -> List[int]:
    out: List[int] = []
    for part in value.split(','):
        part = part.strip()
        if part:
            k = int(part)
            if k < 1:
                raise argparse.ArgumentTypeError("K values must be positive")
            out.append(k)
    if not out:
        raise argparse.ArgumentTypeError("at least one K is required")
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ks", type=parse_ks, default=parse_ks("4,16,64,256"),
                        help="comma-separated K values; default 4,16,64,256")
    parser.add_argument("--outdir", type=Path, default=Path("results/rerun/chain_benchmark"))
    parser.add_argument("--reference", type=Path, default=None)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    rows = [summarize(k) for k in args.ks]

    json_rows = [r.csv_row() for r in rows]
    (args.outdir / "compensation_chain_summary.json").write_text(json.dumps(json_rows, indent=2, sort_keys=True) + "\n")
    with (args.outdir / "compensation_chain_summary.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(json_rows[0].keys()))
        writer.writeheader()
        writer.writerows(json_rows)

    reference_match = None
    reference_errors: List[str] = []
    if args.reference is not None:
        ref = json.loads(args.reference.read_text())
        reference_match = (ref == json_rows)
        if not reference_match:
            reference_errors.append("compensation_chain_summary.json differs from reference")

    summary = {
        "pass": all(r.pass_ for r in rows) and (reference_match is not False),
        "benchmark": "projection_free_compensation_chain",
        "K_values": [r.K for r in rows],
        "rows": json_rows,
        "reference_match": reference_match,
        "reference_errors": reference_errors,
        "certificate": {
            "bits_per_unit": BITS_PER_UNIT,
            "storage": "V_i(z_i)=K times the number of zero bits in the five-bit unit",
            "supply": "0 if c_i=1; -K if c_i=0 and c_{i-1}=1; +1 if c_i=0 and c_{i-1}=0",
            "alpha": "1 outside the all-complete target, 0 on target",
            "no_projection": True,
            "interface_graph": "path",
            "treewidth": 1,
        },
    }
    print(json.dumps(summary, indent=2, sort_keys=True))
    if not summary["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
