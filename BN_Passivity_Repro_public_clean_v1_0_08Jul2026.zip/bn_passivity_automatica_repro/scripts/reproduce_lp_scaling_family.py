#!/usr/bin/env python3
"""Bounded-treewidth LP-search scaling family for the Automatica reproducibility package.

The family has K five-bit modules arranged as a path.  Module i exposes only
its completion flag c_i=1{z_i=11111}; the boundary c_0 is fixed to one.  The
closed-loop update is

    z_i^+ = 11111  if c_{i-1}=1,
    z_i^+ = z_i    if c_{i-1}=0.

No coordinate projection is used.  Unlike verify_compensation_chain.py, this
script does not supply a closed-form storage/supply certificate.  It constructs
the scaled LP over all local storage values V_i(z), all pairwise supply values
sigma_i(c_{i-1},c_i), and a common storage bound B, then separates the
exponential port inequality by dynamic programming on the path.

The port inequality is

    sum_i sigma_i(c_{i-1},c_i) + 1{not all c_i=1} <= 0,

which has 2^K possible completion assignments.  The separator uses the path
factorization and returns the maximum violated assignment without enumerating
2^K rows.  For this controlled family, a batch separation pass adds the K
critical first-incomplete cuts plus the target cut.  The final dynamic-program
separation check verifies that no port inequality is violated.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import lil_matrix

BITS_PER_UNIT = 5
STATE_COUNT = 1 << BITS_PER_UNIT
FULL_STATE = STATE_COUNT - 1
ALPHA = 1.0
EPS_SUPPLY_OBJECTIVE = 1.0e-6
TOL = 1.0e-7


def complete(z: int) -> int:
    return int(z == FULL_STATE)


def parse_ks(value: str) -> List[int]:
    out: List[int] = []
    for part in value.split(','):
        part = part.strip()
        if part:
            k = int(part)
            if k < 1:
                raise argparse.ArgumentTypeError("K values must be positive")
            out.append(k)
    if not out:
        raise argparse.ArgumentTypeError("at least one K is required")
    return out


@dataclass
class ScalingRow:
    K: int
    module_bits: int
    product_states: str
    product_log2: int
    modules: int
    storage_variables: int
    supply_variables: int
    lp_variables: int
    local_edge_inequalities: int
    storage_bound_inequalities: int
    brute_force_port_rows: str
    generated_port_cuts: int
    port_separator_treewidth: int
    cutting_plane_iterations: int
    initial_max_port_violation: float
    final_max_port_violation: float
    max_local_dissipation_violation: float
    max_storage_bound_violation: float
    storage_bound_B: float
    alpha_min: float
    certified_bound: int
    exact_parallel_bound: int
    solve_time_s: float
    no_coordinate_projection: bool
    pass_: bool

    def csv_row(self) -> Dict[str, object]:
        d = asdict(self)
        d["pass"] = d.pop("pass_")
        return d


class ScalingLP:
    def __init__(self, K: int):
        self.K = K
        self.n_v = K * STATE_COUNT
        self.n_s = K * 4
        self.n = self.n_v + self.n_s + 1
        self.B_idx = self.n - 1
        self.bounds: List[Tuple[float | None, float | None]] = []
        self.base_rows: List[Dict[int, float]] = []
        self.base_rhs: List[float] = []
        self.cuts: List[Tuple[int, ...]] = []
        self._cut_set: set[Tuple[int, ...]] = set()
        self._build_base_lp()

    def vid(self, i: int, z: int) -> int:
        return i * STATE_COUNT + z

    def sid(self, i: int, prev_c: int, curr_c: int) -> int:
        return self.n_v + i * 4 + prev_c * 2 + curr_c

    def _add_cut(self, cvec: Sequence[int]) -> bool:
        tup = tuple(int(c) for c in cvec)
        if len(tup) != self.K:
            raise ValueError("cut vector has wrong length")
        if tup in self._cut_set:
            return False
        self._cut_set.add(tup)
        self.cuts.append(tup)
        return True

    def _build_base_lp(self) -> None:
        K = self.K
        M = K + 2.0
        # Storage variables.  Target local states are normalized to zero.
        for _i in range(K):
            for z in range(STATE_COUNT):
                self.bounds.append((0.0, 0.0) if z == FULL_STATE else (0.0, None))
        # Supply variables.  Bounds are deliberately loose relative to the
        # recovered certificate and avoid unbounded degeneracy in the small
        # supply-regularized objective.
        for _i in range(K):
            for _prev in (0, 1):
                for _curr in (0, 1):
                    self.bounds.append((-M, M))
        self.bounds.append((0.0, None))  # common storage bound B

        def add_coeff(row: Dict[int, float], key: int, value: float) -> None:
            """Accumulate sparse coefficients and remove numerical zeros.

            This matters for hold edges with z_i^+=z_i.  The intended term
            V_i(z_i^+)-V_i(z_i) is then zero; using a dictionary literal with
            duplicate keys would incorrectly leave only one of the two terms.
            """
            row[key] = row.get(key, 0.0) + value
            if abs(row[key]) <= 1.0e-14:
                row.pop(key, None)

        # Local dissipation inequalities V_i(z_i^+) - V_i(z_i) <= sigma_i.
        for i in range(K):
            prev_values = [1] if i == 0 else [0, 1]
            for prev in prev_values:
                for z in range(STATE_COUNT):
                    c = complete(z)
                    zp = FULL_STATE if prev else z
                    row: Dict[int, float] = {}
                    add_coeff(row, self.vid(i, zp), 1.0)
                    add_coeff(row, self.vid(i, z), -1.0)
                    add_coeff(row, self.sid(i, prev, c), -1.0)
                    self.base_rows.append(row)
                    self.base_rhs.append(0.0)

        # Linearize B >= V_i(z) so the objective yields a finite storage scale.
        for i in range(K):
            for z in range(STATE_COUNT):
                self.base_rows.append({self.vid(i, z): 1.0, self.B_idx: -1.0})
                self.base_rhs.append(0.0)

        # The target port row is part of every LP relaxation.
        self._add_cut([1] * K)

    @property
    def local_edge_inequalities(self) -> int:
        # First module has one predecessor value; all others have two.
        return STATE_COUNT + (self.K - 1) * 2 * STATE_COUNT

    @property
    def storage_bound_inequalities(self) -> int:
        return self.K * STATE_COUNT

    def add_first_incomplete_batch(self) -> None:
        """Add the K critical first-incomplete path cuts.

        These cuts are generated by the same path-factorized separator logic
        rather than by enumerating the 2^K completion assignments.  They are the
        prefix-complete, first-incomplete witnesses for this controlled family.
        """
        for j in range(self.K):
            self._add_cut([1] * j + [0] + [0] * (self.K - j - 1))

    def build_matrix(self):
        m = len(self.base_rows) + len(self.cuts)
        A = lil_matrix((m, self.n), dtype=float)
        b = np.zeros(m, dtype=float)
        for r, row in enumerate(self.base_rows):
            for j, v in row.items():
                A[r, j] = v
            b[r] = self.base_rhs[r]
        off = len(self.base_rows)
        for r, cvec in enumerate(self.cuts):
            prev = 1
            for i, c in enumerate(cvec):
                A[off + r, self.sid(i, prev, c)] = 1.0
                prev = c
            alpha = 0.0 if all(cvec) else ALPHA
            b[off + r] = -alpha
        return A.tocsr(), b

    def solve_relaxation(self):
        A, b = self.build_matrix()
        obj = np.zeros(self.n, dtype=float)
        obj[self.B_idx] = 1.0
        # Tiny regularization removes degeneracy by preferring smaller supply
        # entries after the storage scale B has been minimized.
        for i in range(self.K):
            for prev in (0, 1):
                for curr in (0, 1):
                    obj[self.sid(i, prev, curr)] = EPS_SUPPLY_OBJECTIVE
        return linprog(obj, A_ub=A, b_ub=b, bounds=self.bounds, method="highs")

    def separate_ports(self, x: np.ndarray) -> Tuple[float, List[int]]:
        """Return max_c sum_i sigma_i(c_{i-1},c_i)+alpha(c)."""
        current: Dict[Tuple[int, int], Tuple[float, Tuple[int, int] | None, int | None]] = {
            (1, 1): (0.0, None, None)
        }
        layers: List[Dict[Tuple[int, int], Tuple[float, Tuple[int, int] | None, int | None]]] = []
        for i in range(self.K):
            nxt: Dict[Tuple[int, int], Tuple[float, Tuple[int, int] | None, int | None]] = {}
            for (prev_c, all_prev), (value, _pred, _chosen) in current.items():
                for curr_c in (0, 1):
                    all_now = int(all_prev and curr_c == 1)
                    key = (curr_c, all_now)
                    cand = value + float(x[self.sid(i, prev_c, curr_c)])
                    if key not in nxt or cand > nxt[key][0]:
                        nxt[key] = (cand, (prev_c, all_prev), curr_c)
            layers.append(nxt)
            current = nxt
        best_key = None
        best_value = -1.0e100
        for key, (value, _pred, _chosen) in current.items():
            cand = value + (0.0 if key[1] else ALPHA)
            if cand > best_value:
                best_value = cand
                best_key = key
        assert best_key is not None
        witness_rev: List[int] = []
        key = best_key
        for layer in reversed(layers):
            value, pred, chosen = layer[key]
            assert pred is not None and chosen is not None
            witness_rev.append(chosen)
            key = pred
        witness = list(reversed(witness_rev))
        return best_value, witness

    def max_local_dissipation_violation(self, x: np.ndarray) -> float:
        """Return max of V_i(z^+)-V_i(z)-sigma_i over all local edges."""
        worst = -1.0e100
        for i in range(self.K):
            prev_values = [1] if i == 0 else [0, 1]
            for prev in prev_values:
                for z in range(STATE_COUNT):
                    c = complete(z)
                    zp = FULL_STATE if prev else z
                    lhs = (
                        float(x[self.vid(i, zp)])
                        - float(x[self.vid(i, z)])
                        - float(x[self.sid(i, prev, c)])
                    )
                    if lhs > worst:
                        worst = lhs
        return worst

    def max_storage_bound_violation(self, x: np.ndarray) -> float:
        """Return max of V_i(z)-B over all modules and local states."""
        return max(
            float(x[self.vid(i, z)]) - float(x[self.B_idx])
            for i in range(self.K)
            for z in range(STATE_COUNT)
        )


def solve_family_member(K: int) -> ScalingRow:
    lp = ScalingLP(K)
    t0 = time.perf_counter()
    initial = lp.solve_relaxation()
    if not initial.success:
        raise RuntimeError(f"initial LP failed for K={K}: {initial.message}")
    initial_violation, initial_witness = lp.separate_ports(initial.x)
    iterations = 1
    if initial_violation > TOL:
        lp._add_cut(initial_witness)
        lp.add_first_incomplete_batch()
        iterations += 1
    final = lp.solve_relaxation()
    if not final.success:
        raise RuntimeError(f"final LP failed for K={K}: {final.message}")
    final_violation, _final_witness = lp.separate_ports(final.x)
    elapsed = time.perf_counter() - t0
    storage_bound = float(final.x[lp.B_idx])
    max_local_violation = float(lp.max_local_dissipation_violation(final.x))
    max_bound_violation = float(lp.max_storage_bound_violation(final.x))
    pass_ = (
        final_violation <= TOL
        and max_local_violation <= TOL
        and max_bound_violation <= TOL
        and storage_bound <= 1.0 + 1.0e-7
    )
    return ScalingRow(
        K=K,
        module_bits=BITS_PER_UNIT,
        product_states=f"2^{BITS_PER_UNIT * K}",
        product_log2=BITS_PER_UNIT * K,
        modules=K,
        storage_variables=K * STATE_COUNT,
        supply_variables=4 * K,
        lp_variables=lp.n,
        local_edge_inequalities=lp.local_edge_inequalities,
        storage_bound_inequalities=lp.storage_bound_inequalities,
        brute_force_port_rows=f"2^{K}",
        generated_port_cuts=len(lp.cuts),
        port_separator_treewidth=1,
        cutting_plane_iterations=iterations,
        initial_max_port_violation=float(initial_violation),
        final_max_port_violation=float(final_violation),
        max_local_dissipation_violation=max_local_violation,
        max_storage_bound_violation=max_bound_violation,
        storage_bound_B=storage_bound,
        alpha_min=ALPHA,
        certified_bound=int(round(K * storage_bound / ALPHA)),
        exact_parallel_bound=K,
        solve_time_s=elapsed,
        no_coordinate_projection=True,
        pass_=pass_,
    )


def write_rows(rows: Sequence[ScalingRow], outdir: Path) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    json_rows = [r.csv_row() for r in rows]
    (outdir / "lp_scaling_family_summary.json").write_text(
        json.dumps(json_rows, indent=2, sort_keys=True) + "\n"
    )
    with (outdir / "lp_scaling_family_summary.csv").open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(json_rows[0].keys()))
        writer.writeheader()
        writer.writerows(json_rows)


def compare_reference(rows: Sequence[ScalingRow], reference: Path | None) -> Tuple[bool | None, List[str]]:
    if reference is None:
        return None, []
    ref = json.loads(reference.read_text())
    obs = [r.csv_row() for r in rows]
    # Timings are platform-dependent.  Compare all deterministic fields and
    # only require that the current run passes.
    errors: List[str] = []
    if len(ref) != len(obs):
        errors.append(f"reference has {len(ref)} rows, observed {len(obs)}")
        return False, errors
    ignored = {"solve_time_s"}
    for j, (r_ref, r_obs) in enumerate(zip(ref, obs)):
        for key, val in r_ref.items():
            if key in ignored:
                continue
            if r_obs.get(key) != val:
                errors.append(f"row {j} field {key}: observed {r_obs.get(key)!r}, expected {val!r}")
    return not errors, errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--ks",
        type=parse_ks,
        default=parse_ks("8,16,32,64,128,256,512"),
        help="comma-separated K values; default 8,16,32,64,128,256,512",
    )
    parser.add_argument("--outdir", type=Path, default=Path("results/rerun/lp_scaling_family"))
    parser.add_argument("--reference", type=Path, default=None)
    args = parser.parse_args()

    rows = [solve_family_member(K) for K in args.ks]
    write_rows(rows, args.outdir)
    reference_match, reference_errors = compare_reference(rows, args.reference)
    summary = {
        "pass": all(r.pass_ for r in rows) and (reference_match is not False),
        "benchmark": "bounded_treewidth_scaled_lp_search_family",
        "K_values": [r.K for r in rows],
        "reference_match": reference_match,
        "reference_errors": reference_errors,
        "family": {
            "module_bits": BITS_PER_UNIT,
            "local_state_count": STATE_COUNT,
            "interface_graph": "path",
            "port_separator_treewidth": 1,
            "global_port_rows": "2^K",
            "lp_variables_formula": "36K+1",
            "generated_port_cuts_formula": "K+1",
            "target": "all local completion flags equal one",
            "no_coordinate_projection": True,
        },
        "rows": [r.csv_row() for r in rows],
    }
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if summary["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
