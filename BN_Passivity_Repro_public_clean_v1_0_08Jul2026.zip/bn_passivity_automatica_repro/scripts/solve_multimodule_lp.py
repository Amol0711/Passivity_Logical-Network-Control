#!/usr/bin/env python3
"""Reusable relation-specific multi-module LP generator for multi-module.

The generator takes a Boolean network, a module partition, and a JSON list of
intervention/retained-variable candidates.  For each candidate it constructs a
projected non-target transition relation under the stated clamps, groups the
retained variables by their original T-LGL modules, builds local edge-cover
storage/supply inequalities, and solves the resulting sparse linear program.

This script is intentionally generic enough for the multi-module gate: it does not modify
or replace the frozen GZMB/MCL1 reference certificate. The reference row is
included only as a smoke test that the generic builder recovers the same bound
and positive-supply compensation using a compressed non-target interface.
"""
from __future__ import annotations

import argparse
import ast
import csv
import json
import math
import re
import sys
import time
from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, Mapping, Sequence, Tuple

try:
    import numpy as np
    from scipy.optimize import linprog
    from scipy.sparse import coo_matrix
except Exception as exc:  # pragma: no cover
    raise SystemExit("solve_multimodule_lp.py requires scipy and numpy") from exc

try:
    from sympy import simplify_logic, symbols, sympify
except Exception as exc:  # pragma: no cover
    raise SystemExit("solve_multimodule_lp.py requires sympy") from exc

NAME_TOKEN = re.compile(r"\bv_[A-Za-z0-9_]+\b")
KEYWORDS = {"and", "or", "not", "True", "False"}
DEFAULT_CONFIG = Path("configs/multimodule_certificate_candidates.json")
TARGET_DEFAULT = "v_Apoptosis"


@dataclass(frozen=True)
class CompiledRule:
    expr_text: str
    dependencies: Tuple[str, ...]
    evaluate: Callable[[Mapping[str, int]], int]


def parse_bnet(path: Path) -> Dict[str, str]:
    rules: Dict[str, str] = {}
    with path.open("r", encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.lower().replace(" ", "") in {"targets,factors", "target,factor"}:
                continue
            if "," not in line:
                continue
            lhs, rhs = (part.strip() for part in line.split(",", 1))
            rules[lhs] = rhs
    if not rules:
        raise RuntimeError(f"no Boolean rules found in {path}")
    return rules


def parse_partition(path: Path) -> Tuple[Dict[str, str], Dict[str, str], Dict[str, int], Dict[str, Sequence[str]]]:
    node_to_module: Dict[str, str] = {}
    module_label: Dict[str, str] = {}
    module_size: Dict[str, int] = {}
    module_nodes: Dict[str, Sequence[str]] = {}
    with path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            mid = row["module_id"]
            module_label[mid] = row.get("module_label", mid)
            module_size[mid] = int(row["node_count"])
            nodes = tuple(node.strip() for node in row["nodes"].split(";") if node.strip())
            module_nodes[mid] = nodes
            for node in nodes:
                node_to_module[node] = mid
    return node_to_module, module_label, module_size, module_nodes


def make_sympy_expr(expr: str, syms: Mapping[str, object]):
    # BNET syntax is already close to Python/SymPy boolean syntax except !.
    return sympify(expr.replace("!", "~"), locals=syms)


def sympy_to_python_bool(expr: object) -> str:
    text = str(expr)
    text = text.replace("~", " not ")
    text = text.replace("&", " and ")
    text = text.replace("|", " or ")
    return text.strip()


def compile_expr(expr: object) -> CompiledRule:
    src = sympy_to_python_bool(expr)
    try:
        code = compile(ast.parse(src, mode="eval"), "<logical_rule>", "eval")
    except SyntaxError as exc:
        raise RuntimeError(f"could not compile simplified expression: {src}") from exc
    deps = tuple(sorted(tok for tok in NAME_TOKEN.findall(src) if tok not in KEYWORDS))

    def evaluate(env: Mapping[str, int]) -> int:
        locals_env = {tok: bool(env.get(tok, 0)) for tok in deps}
        return int(bool(eval(code, {"__builtins__": {}}, locals_env)))

    return CompiledRule(expr_text=src, dependencies=deps, evaluate=evaluate)


def bool_product(names: Sequence[str], fixed: Mapping[str, int] | None = None) -> Iterable[Tuple[int, ...]]:
    fixed = fixed or {}
    free_names = [name for name in names if name not in fixed]
    for vals in product((0, 1), repeat=len(free_names)):
        env = dict(fixed)
        env.update({name: vals[i] for i, name in enumerate(free_names)})
        yield tuple(env[name] for name in names)


def load_config(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def simplify_candidate_rules(
    rules: Mapping[str, str],
    candidate: Mapping[str, Any],
    target: str,
) -> Dict[str, Any]:
    retained = list(dict.fromkeys(candidate["retained"]))
    clamps = {str(k): int(v) for k, v in candidate.get("clamps", {}).items()}
    state_vars = [node for node in retained if node not in clamps]
    if target not in state_vars:
        state_vars = [target] + [node for node in state_vars if node != target]
    else:
        state_vars = [target] + [node for node in state_vars if node != target]

    all_names = sorted(set(rules) | {tok for expr in rules.values() for tok in NAME_TOKEN.findall(expr)} | set(retained) | set(clamps))
    syms = {name: symbols(name) for name in all_names}
    exprs = {name: make_sympy_expr(expr, syms) for name, expr in rules.items()}
    substitutions = {syms[target]: False}
    for node, value in clamps.items():
        substitutions[syms[node]] = bool(value)

    compiled: Dict[str, CompiledRule] = {}
    simplified_rules: Dict[str, str] = {}
    dependencies: Dict[str, Sequence[str]] = {}
    dep_tokens: set[str] = set()
    for node in state_vars:
        if node not in exprs:
            raise RuntimeError(f"candidate {candidate.get('candidate_id')} retained unknown state variable {node}")
        expr = simplify_logic(exprs[node].subs(substitutions), form="dnf")
        rule = compile_expr(expr)
        compiled[node] = rule
        simplified_rules[node] = rule.expr_text
        dependencies[node] = list(rule.dependencies)
        dep_tokens.update(rule.dependencies)
    ports = sorted(tok for tok in dep_tokens if tok not in state_vars and tok not in clamps)
    return {
        "state_variables": state_vars,
        "ports": ports,
        "clamps": clamps,
        "compiled_rules": compiled,
        "simplified_rules": simplified_rules,
        "dependencies": dependencies,
    }


def compute_exact_demonic_bound(projected: Mapping[str, Any], target: str) -> Dict[str, Any]:
    state_vars = list(projected["state_variables"])
    ports = list(projected["ports"])
    compiled: Mapping[str, CompiledRule] = projected["compiled_rules"]
    clamps: Mapping[str, int] = projected["clamps"]
    idx = {node: i for i, node in enumerate(state_vars)}
    states = list(product((0, 1), repeat=len(state_vars)))
    port_values = list(product((0, 1), repeat=len(ports)))

    def is_target(state: Tuple[int, ...]) -> bool:
        return state[idx[target]] == 1

    successor_cache: Dict[Tuple[int, ...], set[Tuple[int, ...]]] = {}

    def successors(state: Tuple[int, ...]) -> set[Tuple[int, ...]]:
        if is_target(state):
            return {state}
        if state in successor_cache:
            return successor_cache[state]
        base = {node: state[idx[node]] for node in state_vars}
        base.update(clamps)
        base[target] = 0
        outs: set[Tuple[int, ...]] = set()
        for pvals in port_values:
            env = dict(base)
            env.update({port: pvals[j] for j, port in enumerate(ports)})
            outs.add(tuple(compiled[node].evaluate(env) for node in state_vars))
        successor_cache[state] = outs
        return outs

    H: Dict[Tuple[int, ...], int | None] = {state: (0 if is_target(state) else None) for state in states}
    changed = True
    while changed:
        changed = False
        for state in states:
            if H[state] is not None:
                continue
            succ = successors(state)
            if all(H[s] is not None for s in succ):
                H[state] = 1 + max(int(H[s]) for s in succ)  # type: ignore[arg-type]
                changed = True
    unresolved = [state for state in states if H[state] is None]
    finite = [int(v) for state, v in H.items() if not is_target(state) and v is not None]
    max_h = max(finite) if finite else None
    return {
        "state_count": len(states),
        "non_target_state_count": sum(1 for s in states if not is_target(s)),
        "port_assignment_count": len(port_values),
        "transition_row_count": sum(1 for s in states if not is_target(s)) * len(port_values),
        "exact_projected_bound": max_h,
        "unresolved_state_count": len(unresolved),
        "unresolved_states": [dict(zip(state_vars, state)) for state in unresolved[:25]],
        "hitting_times": [
            {"state": dict(zip(state_vars, state)), "hitting_time": H[state]}
            for state in states
        ],
    }


def candidate_module_data(
    projected: Mapping[str, Any],
    candidate: Mapping[str, Any],
    node_to_module: Mapping[str, str],
    module_size: Mapping[str, int],
) -> Dict[str, Any]:
    target = "v_Apoptosis"
    state_vars = list(projected["state_variables"])
    clamps = dict(projected["clamps"])
    module_vars: Dict[str, list[str]] = {}
    for node in state_vars:
        mid = node_to_module.get(node, "UNASSIGNED")
        module_vars.setdefault(mid, []).append(node)
    modules = list(module_vars.keys())
    target_module = node_to_module.get(target, modules[0])
    active_modules = set(modules)
    for node in clamps:
        if node in node_to_module:
            active_modules.add(node_to_module[node])
    product_exponent = sum(module_size.get(mid, 0) for mid in sorted(active_modules))
    return {
        "module_vars": module_vars,
        "modules": modules,
        "target_module": target_module,
        "active_original_modules": sorted(active_modules),
        "active_original_module_count": len(active_modules),
        "original_module_product_exponent": product_exponent,
    }


def build_lp(
    projected: Mapping[str, Any],
    candidate: Mapping[str, Any],
    module_data: Mapping[str, Any],
    target: str,
    tol: float = 1e-8,
) -> Dict[str, Any]:
    state_vars = list(projected["state_variables"])
    ports = list(projected["ports"])
    clamps = dict(projected["clamps"])
    compiled: Mapping[str, CompiledRule] = projected["compiled_rules"]
    dependencies: Mapping[str, Sequence[str]] = projected["dependencies"]
    idx = {node: i for i, node in enumerate(state_vars)}

    module_vars: Dict[str, list[str]] = {mid: list(vars_) for mid, vars_ in module_data["module_vars"].items()}
    modules: list[str] = list(module_data["modules"])
    target_module = module_data["target_module"]

    # Local external context variables for each module: variables used by module rules
    # that are not local state variables.  These may be other retained module states
    # or universal projected ports.
    module_context: Dict[str, list[str]] = {}
    for mid, vars_ in module_vars.items():
        local = set(vars_)
        ctx: set[str] = set()
        for node in vars_:
            for dep in dependencies.get(node, []):
                if dep not in local and dep not in clamps:
                    ctx.add(dep)
        module_context[mid] = sorted(ctx)

    # Enumerate non-target global rows and discover unique local edge-cover rows.
    non_target_fixed = {target: 0}
    non_target_states = list(bool_product(state_vars, non_target_fixed))
    port_values = list(product((0, 1), repeat=len(ports)))

    edge_keys: Dict[Tuple[Any, ...], int] = {}
    edge_records: list[Dict[str, Any]] = []
    port_rows: list[Tuple[Tuple[int, ...], Tuple[int, ...], Tuple[int, ...]]] = []

    def get_edge_id(key: Tuple[Any, ...], record: Dict[str, Any]) -> int:
        if key in edge_keys:
            return edge_keys[key]
        edge_id = len(edge_records)
        edge_keys[key] = edge_id
        edge_records.append(record)
        return edge_id

    for state in non_target_states:
        base = {node: state[idx[node]] for node in state_vars}
        base.update(clamps)
        base[target] = 0
        for pvals in port_values:
            env = dict(base)
            env.update({port: pvals[j] for j, port in enumerate(ports)})
            next_state = tuple(compiled[node].evaluate(env) for node in state_vars)
            row_edge_ids = []
            for mid in modules:
                vars_ = module_vars[mid]
                cur_local = tuple(env[node] for node in vars_)
                next_local = tuple(next_state[idx[node]] for node in vars_)
                ctx_names = module_context[mid]
                ctx_vals = tuple(env[node] for node in ctx_names)
                key = (mid, cur_local, tuple(ctx_names), ctx_vals, next_local)
                rec = {
                    "edge_id": None,
                    "module_id": mid,
                    "module_vars": vars_,
                    "current_local": cur_local,
                    "context_names": ctx_names,
                    "context_values": ctx_vals,
                    "next_local": next_local,
                }
                row_edge_ids.append(get_edge_id(key, rec))
            port_rows.append((state, pvals, tuple(row_edge_ids)))

    for edge_id, rec in enumerate(edge_records):
        rec["edge_id"] = edge_id

    # Storage variables for all local states of projected modules.
    storage_keys: list[Tuple[str, Tuple[int, ...]]] = []
    for mid in modules:
        vars_ = module_vars[mid]
        for vals in product((0, 1), repeat=len(vars_)):
            storage_keys.append((mid, tuple(vals)))
    storage_index = {key: i for i, key in enumerate(storage_keys)}
    sigma_offset = len(storage_keys)
    sigma_index = {edge_id: sigma_offset + edge_id for edge_id in range(len(edge_records))}
    B_index = sigma_offset + len(edge_records)
    nvars = B_index + 1

    rows: list[int] = []
    cols: list[int] = []
    data: list[float] = []
    b_ub: list[float] = []

    def add_coeff(r: int, c: int, val: float) -> None:
        if abs(val) > 0:
            rows.append(r); cols.append(c); data.append(float(val))

    row = 0
    # Local edge inequalities: V(next)-V(cur)-sigma <= 0.
    for edge_id, rec in enumerate(edge_records):
        mid = rec["module_id"]
        cur_key = (mid, tuple(rec["current_local"]))
        next_key = (mid, tuple(rec["next_local"]))
        add_coeff(row, storage_index[next_key], 1.0)
        add_coeff(row, storage_index[cur_key], -1.0)
        add_coeff(row, sigma_index[edge_id], -1.0)
        b_ub.append(0.0)
        row += 1

    # Port/global interconnection rows: sum of selected local supplies <= -1.
    for _state, _pvals, edge_ids in port_rows:
        for edge_id in edge_ids:
            add_coeff(row, sigma_index[edge_id], 1.0)
        b_ub.append(-1.0)
        row += 1

    # Bound rows: sum of local storages at non-target state <= B.
    for state in non_target_states:
        env = {node: state[idx[node]] for node in state_vars}
        for mid in modules:
            vars_ = module_vars[mid]
            key = (mid, tuple(env[node] for node in vars_))
            add_coeff(row, storage_index[key], 1.0)
        add_coeff(row, B_index, -1.0)
        b_ub.append(0.0)
        row += 1

    A_ub = coo_matrix((data, (rows, cols)), shape=(row, nvars)).tocsr()
    b_vec = np.array(b_ub, dtype=float)
    c = np.zeros(nvars, dtype=float)
    c[B_index] = 1.0

    bounds: list[Tuple[float | None, float | None]] = []
    for mid, vals in storage_keys:
        if mid == target_module and target in module_vars[mid]:
            tpos = module_vars[mid].index(target)
            if vals[tpos] == 1:
                bounds.append((0.0, 0.0))
            else:
                bounds.append((0.0, None))
        else:
            bounds.append((0.0, None))
    for _ in edge_records:
        bounds.append((None, None))
    bounds.append((0.0, None))

    t0 = time.time()
    result = linprog(c, A_ub=A_ub, b_ub=b_vec, bounds=bounds, method="highs")
    solve_seconds = time.time() - t0
    if not result.success:
        return {
            "lp_success": False,
            "linprog_message": result.message,
            "solve_seconds": solve_seconds,
            "variable_count": nvars,
            "inequality_count": int(A_ub.shape[0]),
            "nonzero_count": int(A_ub.nnz),
            "local_edge_count": len(edge_records),
            "local_edge_inequality_count": len(edge_records),
            "port_cover_count": len(port_rows),
            "port_inequality_count": len(port_rows),
            "storage_bound_inequality_count": len(non_target_states),
            "storage_variable_count": len(storage_keys),
            "supply_variable_count": len(edge_records),
            "bound_variable_count": 1,
            "module_count_projected": len(modules),
            "edge_records": edge_records,
            "module_context": module_context,
        }

    x = np.asarray(result.x)
    storage_values = {f"{mid}:{''.join(map(str, vals))}": float(x[var_idx]) for (mid, vals), var_idx in storage_index.items()}
    sigma_values = {edge_id: float(x[sigma_index[edge_id]]) for edge_id in range(len(edge_records))}

    tight_count = 0
    positive_supply_count = 0
    compensated_count = 0
    port_samples: list[Dict[str, Any]] = []
    compensated_samples: list[Dict[str, Any]] = []
    max_port_sample_rows = int(candidate.get("max_port_sample_rows", 50))
    max_comp_sample_rows = int(candidate.get("max_compensated_sample_rows", 100))
    min_slack = math.inf
    max_slack = -math.inf
    for row_id, (state, pvals, edge_ids) in enumerate(port_rows):
        sigmas = [sigma_values[eid] for eid in edge_ids]
        total = float(sum(sigmas))
        slack = -1.0 - total  # nonnegative if constraint is satisfied
        min_slack = min(min_slack, slack)
        max_slack = max(max_slack, slack)
        is_tight = abs(total + 1.0) <= 1e-7
        has_pos = any(val > 1e-7 for val in sigmas)
        has_neg = any(val < -1e-7 for val in sigmas)
        if is_tight:
            tight_count += 1
        if has_pos:
            positive_supply_count += 1
        if has_pos and has_neg and total <= -1.0 + 1e-7:
            compensated_count += 1
        sample_row = None
        if len(port_samples) < max_port_sample_rows or (has_pos and has_neg and len(compensated_samples) < max_comp_sample_rows):
            sample_row = {
                "row_id": row_id,
                "state": dict(zip(state_vars, state)),
                "ports": dict(zip(ports, pvals)),
                "edge_ids": list(edge_ids),
                "module_sigmas": {modules[i]: sigmas[i] for i in range(len(modules))},
                "sigma_sum": total,
                "slack": slack,
                "tight": is_tight,
                "compensated_positive_supply": has_pos and has_neg and total <= -1.0 + 1e-7,
            }
        if sample_row is not None and len(port_samples) < max_port_sample_rows:
            port_samples.append(sample_row)
        if sample_row is not None and sample_row["compensated_positive_supply"] and len(compensated_samples) < max_comp_sample_rows:
            compensated_samples.append(sample_row)

    # Bound constraints diagnostics over non-target global states.
    max_initial_storage = -math.inf
    for state in non_target_states:
        env = {node: state[idx[node]] for node in state_vars}
        total = 0.0
        for mid in modules:
            vals = tuple(env[node] for node in module_vars[mid])
            total += x[storage_index[(mid, vals)]]
        max_initial_storage = max(max_initial_storage, total)

    return {
        "lp_success": True,
        "linprog_message": result.message,
        "solve_seconds": solve_seconds,
        "lp_bound": float(x[B_index]),
        "max_initial_storage": float(max_initial_storage),
        "variable_count": nvars,
        "inequality_count": int(A_ub.shape[0]),
        "nonzero_count": int(A_ub.nnz),
        "local_edge_count": len(edge_records),
        "local_edge_inequality_count": len(edge_records),
        "port_cover_count": len(port_rows),
        "port_inequality_count": len(port_rows),
        "storage_bound_inequality_count": len(non_target_states),
        "storage_variable_count": len(storage_keys),
        "supply_variable_count": len(edge_records),
        "bound_variable_count": 1,
        "module_count_projected": len(modules),
        "tight_port_count": tight_count,
        "positive_supply_port_count": positive_supply_count,
        "compensated_positive_supply_port_count": compensated_count,
        "min_port_slack": float(min_slack),
        "max_port_slack": float(max_slack),
        "storage_values": storage_values,
        "edge_records": edge_records,
        "sigma_values": sigma_values,
        "port_samples": port_samples,
        "compensated_samples": compensated_samples,
        "module_context": module_context,
    }


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]], fieldnames: Sequence[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        keys: list[str] = []
        for row in rows:
            for key in row.keys():
                if key not in keys:
                    keys.append(key)
        fieldnames = keys
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in fieldnames})


def jsonable(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [jsonable(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    return obj


def write_candidate_outputs(outdir: Path, candidate: Mapping[str, Any], projected: Mapping[str, Any], exact: Mapping[str, Any], module_data: Mapping[str, Any], lp: Mapping[str, Any], stable_only: bool = False) -> Dict[str, Any]:
    cid = candidate["candidate_id"]
    cdir = outdir / cid
    cdir.mkdir(parents=True, exist_ok=True)

    # Stable summary for the candidate.
    summary = {
        "candidate_id": cid,
        "label": candidate.get("label", ""),
        "priority": candidate.get("priority", ""),
        "route": candidate.get("route", ""),
        "clamps": candidate.get("clamps", {}),
        "state_variables": projected["state_variables"],
        "universal_ports": projected["ports"],
        "state_variable_count": len(projected["state_variables"]),
        "universal_port_count": len(projected["ports"]),
        "projected_state_count": exact["state_count"],
        "non_target_state_count": exact["non_target_state_count"],
        "transition_row_count": exact["transition_row_count"],
        "exact_projected_bound": exact["exact_projected_bound"],
        "unresolved_state_count": exact["unresolved_state_count"],
        "projected_modules": module_data["modules"],
        "module_count_projected": lp.get("module_count_projected", len(module_data["modules"])),
        "active_original_modules": module_data["active_original_modules"],
        "active_original_module_count": module_data["active_original_module_count"],
        "original_module_product_exponent": module_data["original_module_product_exponent"],
        "lp_success": lp.get("lp_success", False),
        "lp_bound": lp.get("lp_bound"),
        "variable_count": lp.get("variable_count"),
        "inequality_count": lp.get("inequality_count"),
        "nonzero_count": lp.get("nonzero_count"),
        "local_edge_count": lp.get("local_edge_count"),
        "local_edge_inequality_count": lp.get("local_edge_inequality_count"),
        "port_cover_count": lp.get("port_cover_count"),
        "port_inequality_count": lp.get("port_inequality_count"),
        "storage_bound_inequality_count": lp.get("storage_bound_inequality_count"),
        "storage_variable_count": lp.get("storage_variable_count"),
        "supply_variable_count": lp.get("supply_variable_count"),
        "bound_variable_count": lp.get("bound_variable_count"),
        "tight_port_count": lp.get("tight_port_count"),
        "positive_supply_port_count": lp.get("positive_supply_port_count"),
        "compensated_positive_supply_port_count": lp.get("compensated_positive_supply_port_count"),
        "min_port_slack": lp.get("min_port_slack"),
        "max_port_slack": lp.get("max_port_slack"),
        "linprog_message": lp.get("linprog_message", ""),
        "promotion_eligible_by_lp": bool(lp.get("lp_success")) and int(module_data["active_original_module_count"]) >= 3 and int(lp.get("module_count_projected", 0)) >= 3 and int(lp.get("compensated_positive_supply_port_count", 0) or 0) > 0 and exact["exact_projected_bound"] is not None,
        "notes": candidate.get("notes", ""),
    }
    # Keep solve_seconds out of stable candidate summary; write separately.
    runtime = {"candidate_id": cid, "solve_seconds": lp.get("solve_seconds")}

    (cdir / "candidate_summary.json").write_text(json.dumps(jsonable(summary), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (cdir / "runtime.json").write_text(json.dumps(jsonable(runtime), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (cdir / "simplified_rules.json").write_text(json.dumps(jsonable(projected["simplified_rules"]), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (cdir / "module_context.json").write_text(json.dumps(jsonable(lp.get("module_context", {})), indent=2, sort_keys=True) + "\n", encoding="utf-8")

    # Local edge cover table.
    edge_rows = []
    sigma_values = lp.get("sigma_values", {})
    for rec in lp.get("edge_records", []):
        edge_id = rec["edge_id"]
        edge_rows.append({
            "edge_id": edge_id,
            "module_id": rec["module_id"],
            "module_vars": ";".join(rec["module_vars"]),
            "current_local": "".join(map(str, rec["current_local"])),
            "context_names": ";".join(rec["context_names"]),
            "context_values": "".join(map(str, rec["context_values"])),
            "next_local": "".join(map(str, rec["next_local"])),
            "sigma": sigma_values.get(edge_id, ""),
        })
    if edge_rows:
        write_csv(cdir / "local_edge_cover.csv", edge_rows)

    if lp.get("storage_values"):
        write_csv(cdir / "storage_values.csv", [
            {"storage_key": key, "value": value}
            for key, value in sorted(lp["storage_values"].items())
        ])

    # Hitting time table: useful but not too large for these projected kernels.
    write_csv(cdir / "projected_hitting_times.csv", [
        {"state": json.dumps(row["state"], sort_keys=True), "hitting_time": row["hitting_time"]}
        for row in exact["hitting_times"]
    ], fieldnames=["state", "hitting_time"])

    # Store only samples for huge port covers. Counts are in the summary.
    if lp.get("port_samples"):
        write_csv(cdir / "port_inequalities_sample.csv", [
            {
                "row_id": row["row_id"],
                "state": json.dumps(row["state"], sort_keys=True),
                "ports": json.dumps(row["ports"], sort_keys=True),
                "edge_ids": ";".join(map(str, row["edge_ids"])),
                "module_sigmas": json.dumps(row["module_sigmas"], sort_keys=True),
                "sigma_sum": row["sigma_sum"],
                "slack": row["slack"],
                "tight": int(row["tight"]),
                "compensated_positive_supply": int(row["compensated_positive_supply"]),
            }
            for row in lp["port_samples"]
        ])
    if lp.get("compensated_samples"):
        write_csv(cdir / "compensated_positive_supply_ports_sample.csv", [
            {
                "row_id": row["row_id"],
                "state": json.dumps(row["state"], sort_keys=True),
                "ports": json.dumps(row["ports"], sort_keys=True),
                "edge_ids": ";".join(map(str, row["edge_ids"])),
                "module_sigmas": json.dumps(row["module_sigmas"], sort_keys=True),
                "sigma_sum": row["sigma_sum"],
                "slack": row["slack"],
            }
            for row in lp["compensated_samples"]
        ])
    return summary


def stable_summary_row(summary: Mapping[str, Any]) -> Dict[str, Any]:
    keys = [
        "candidate_id", "label", "priority", "route", "state_variable_count", "universal_port_count",
        "projected_state_count", "non_target_state_count", "transition_row_count", "exact_projected_bound",
        "unresolved_state_count", "module_count_projected", "active_original_module_count",
        "original_module_product_exponent", "lp_success", "lp_bound", "variable_count", "inequality_count",
        "nonzero_count", "local_edge_count", "local_edge_inequality_count", "port_cover_count",
        "port_inequality_count", "storage_bound_inequality_count", "storage_variable_count",
        "supply_variable_count", "bound_variable_count", "tight_port_count", "positive_supply_port_count",
        "compensated_positive_supply_port_count",
        "min_port_slack", "max_port_slack", "promotion_eligible_by_lp", "linprog_message",
    ]
    return {key: summary.get(key) for key in keys}


def run(config_path: Path, outdir: Path, candidate_filter: Sequence[str] | None = None) -> Dict[str, Any]:
    cfg = load_config(config_path)
    root = config_path.parent.parent
    model_path = root / cfg.get("model_path", "model/tlgl_2011_survival_network.bnet")
    partition_path = root / cfg.get("partition_path", "model/tlgl_2011_module_partition.csv")
    target = cfg.get("target", TARGET_DEFAULT)
    rules = parse_bnet(model_path)
    node_to_module, module_label, module_size, module_nodes = parse_partition(partition_path)
    candidates = cfg["candidates"]
    if candidate_filter:
        wanted = set(candidate_filter)
        candidates = [c for c in candidates if c["candidate_id"] in wanted]
        missing = wanted - {c["candidate_id"] for c in candidates}
        if missing:
            raise RuntimeError(f"candidate ids not found in config: {sorted(missing)}")

    outdir.mkdir(parents=True, exist_ok=True)
    all_summaries: list[Dict[str, Any]] = []
    for cand in candidates:
        projected = simplify_candidate_rules(rules, cand, target)
        exact = compute_exact_demonic_bound(projected, target)
        module_data = candidate_module_data(projected, cand, node_to_module, module_size)
        lp = build_lp(projected, cand, module_data, target)
        summary = write_candidate_outputs(outdir, cand, projected, exact, module_data, lp)
        all_summaries.append(summary)

    stable_rows = [stable_summary_row(s) for s in all_summaries]
    (outdir / "multimodule_lp_summary.json").write_text(json.dumps(jsonable(stable_rows), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    write_csv(outdir / "multimodule_lp_summary.csv", stable_rows)
    stdout_summary = {
        "pass": all(bool(s.get("lp_success")) for s in all_summaries),
        "candidate_count": len(all_summaries),
        "solved_candidates": [s["candidate_id"] for s in all_summaries if s.get("lp_success")],
        "promotion_eligible_by_lp": [s["candidate_id"] for s in all_summaries if s.get("promotion_eligible_by_lp")],
        "outdir": str(outdir),
    }
    (outdir / "stdout_summary.json").write_text(json.dumps(jsonable(stdout_summary), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return stdout_summary


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG, help="candidate JSON relative to reproducibility root")
    parser.add_argument("--outdir", type=Path, default=Path("results/rerun/multimodule_lp"), help="output directory")
    parser.add_argument("--candidate", action="append", help="optional candidate_id filter; may be repeated")
    args = parser.parse_args(argv)
    config_path = args.config
    if not config_path.is_absolute():
        config_path = Path.cwd() / config_path
    outdir = args.outdir
    if not outdir.is_absolute():
        outdir = Path.cwd() / outdir
    result = run(config_path, outdir, args.candidate)
    print(json.dumps(jsonable(result), indent=2, sort_keys=True))
    return 0 if result.get("pass") else 2


if __name__ == "__main__":
    raise SystemExit(main())
