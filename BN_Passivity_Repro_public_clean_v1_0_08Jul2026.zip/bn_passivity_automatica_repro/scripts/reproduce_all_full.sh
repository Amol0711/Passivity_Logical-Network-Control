#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
RERUN_ROOT="${1:-$ROOT/results/rerun}"
rm -rf "$RERUN_ROOT"
mkdir -p "$RERUN_ROOT"
python3 "$ROOT/scripts/verify_gzmb_mcl1_certificate.py" --data "$ROOT/data" --outdir "$RERUN_ROOT/verify_frozen" > "$RERUN_ROOT/verify_frozen_stdout.json"
python3 "$ROOT/scripts/solve_gzmb_mcl1_lp.py" --outdir "$RERUN_ROOT/solve" > "$RERUN_ROOT/solve_stdout.json"
python3 "$ROOT/scripts/verify_gzmb_mcl1_certificate.py" --data "$RERUN_ROOT/solve" --outdir "$RERUN_ROOT/verify_solve" > "$RERUN_ROOT/verify_solve_stdout.json"
python3 "$ROOT/scripts/screen_candidate_interventions.py" --outdir "$RERUN_ROOT/candidate_screen" > "$RERUN_ROOT/candidate_screen_stdout.json"
python3 "$ROOT/scripts/verify_compensation_chain.py" \
  --outdir "$RERUN_ROOT/chain_benchmark" \
  --reference "$ROOT/results/reference/chain_benchmark/compensation_chain_summary.json" \
  > "$RERUN_ROOT/chain_benchmark_stdout.json"
bash "$ROOT/scripts/reproduce_multimodule_lp.sh" "$RERUN_ROOT/multimodule_lp" > "$RERUN_ROOT/multimodule_lp_stdout.json"
python3 "$ROOT/scripts/evaluate_tpl2_s1p_promotion.py" --multimodule-outdir "$RERUN_ROOT/multimodule_lp" --outdir "$RERUN_ROOT/tpl2_s1p_promotion_evaluation" > "$RERUN_ROOT/tpl2_s1p_promotion_evaluation_stdout.json"
python3 - "$ROOT/results/reference/tpl2_s1p_promotion" "$RERUN_ROOT/tpl2_s1p_promotion_evaluation" > "$RERUN_ROOT/promotion_reference_compare_stdout.json" <<'PY'
import json, sys
from pathlib import Path
ref=Path(sys.argv[1]); rerun=Path(sys.argv[2])
errors=[]
for name in ["promotion_recommendation.json", "tpl2_s1p_promotion_evaluation.json", "clamp_load_bearing.csv"]:
    if (ref/name).read_text() != (rerun/name).read_text():
        errors.append(f"{name} differs between reference and rerun")
summary={"pass": not errors, "reference": str(ref), "rerun_evaluation": str(rerun), "errors": errors[:20]}
print(json.dumps(summary, indent=2, sort_keys=True))
if errors:
    raise SystemExit(1)
PY
python3 - "$RERUN_ROOT" <<'PY'
import json, sys
from pathlib import Path
rerun=Path(sys.argv[1])
vf=json.loads((rerun/'verify_frozen_stdout.json').read_text())
vs=json.loads((rerun/'verify_solve_stdout.json').read_text())
so=json.loads((rerun/'solve_stdout.json').read_text())
cs=json.loads((rerun/'candidate_screen_stdout.json').read_text())
chain=json.loads((rerun/'chain_benchmark_stdout.json').read_text())
d2=json.loads((rerun/'multimodule_lp_stdout.json').read_text())
promotion=json.loads((rerun/'tpl2_s1p_promotion_evaluation_stdout.json').read_text())
promotion_cmp=json.loads((rerun/'promotion_reference_compare_stdout.json').read_text())
chain_rows=chain.get('rows') or []
summary={
 'pass': bool(vf.get('pass') and vs.get('pass') and so.get('pass') and cs.get('pass') and chain.get('pass') and d2.get('pass') and promotion.get('pass') and promotion_cmp.get('pass')),
 'rerun_root': str(rerun),
 'frozen_certificate_pass': bool(vf.get('pass')),
 'solver_rerun_pass': bool(so.get('pass')),
 'solver_rerun_verified_pass': bool(vs.get('pass')),
 'candidate_screen_pass': bool(cs.get('pass')),
 'compensation_chain_pass': bool(chain.get('pass')),
 'multimodule_lp_pass': bool(d2.get('pass')),
 'tpl2_s1p_promotion_evaluation_pass': bool(promotion.get('pass')),
 'promotion_reference_compare_pass': bool(promotion_cmp.get('pass')),
 'stable_values': {'variables': so.get('variables'), 'inequalities': so.get('inequalities'), 'local_edges': so.get('local_edges'), 'port_cover': so.get('port_cover'), 'compensated_ports': so.get('compensated_ports'), 'kernel_exact_max': so.get('kernel_exact_max'), 'certified_bound': so.get('bound')},
 'compensation_chain': {'K_values': chain.get('K_values'), 'benchmark': chain.get('benchmark'), 'max_reported_product_states': chain_rows[-1].get('product_states') if chain_rows else None, 'max_reported_K': chain_rows[-1].get('K') if chain_rows else None, 'reference_match': chain.get('reference_match')},
 'candidate_screen': {'candidate_count': cs.get('candidate_count'), 'promote_to_candidate_primary': cs.get('promote_to_candidate_primary'), 'finite_projected_candidates': cs.get('finite_projected_candidates'), 'negative_controls': cs.get('negative_controls')},
 'multimodule_lp': {'candidate_count': d2.get('candidate_count'), 'solved_candidates': d2.get('solved_candidates'), 'promotion_eligible_by_lp': d2.get('promotion_eligible_by_lp')},
 'tpl2_s1p_promotion_evaluation': {'primary': promotion.get('primary'), 'reserve_candidates': promotion.get('reserve_candidates'), 'evaluated_candidates': promotion.get('evaluated_candidates')},
 'runtime_note': 'solve_seconds and candidate screen/multi-module/promotion runtimes are reported only in generated rerun outputs and are intentionally excluded from stable data files.'}
print(json.dumps(summary, indent=2, sort_keys=True))
if not summary['pass']:
    raise SystemExit(1)
PY
