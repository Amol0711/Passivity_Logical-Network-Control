#!/usr/bin/env python3
"""Candidate screening for optional larger projected-intervention experiments.

This script performs a conservative, non-destructive screening pass.  It does
not claim a compositional LP certificate.  For each candidate intervention it:

1. simplifies the retained projected rules under the non-target guard
   Apoptosis=0 and the stated clamps;
2. treats all remaining dependencies outside the retained set as universally
   quantified Boolean ports;
3. computes exact demonic-port hitting times on the projected kernel; and
4. optionally checks for a concrete non-apoptotic full-BNET fixed point using
   SymPy's SAT routine.

The screen enumerates only projected kernels and port covers, never the 2^54
full internal state graph.
"""
from __future__ import annotations

import argparse
import ast
import csv
import json
import re
from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Callable, Dict, Iterable, Mapping, Sequence, Tuple

try:
    from sympy import And, Equivalent, Not, satisfiable, simplify_logic, symbols, sympify
except Exception as exc:  # pragma: no cover
    raise SystemExit("screen_candidate_interventions.py requires sympy; install requirements.txt") from exc

NAME_TOKEN = re.compile(r"\bv_[A-Za-z0-9_]+\b")
KEYWORDS = {"and", "or", "not", "True", "False"}
TARGET = "v_Apoptosis"


@dataclass(frozen=True)
class Candidate:
    candidate_id: str
    intervention_label: str
    route_label: str
    clamps: Mapping[str, int]
    retained: Sequence[str]
    priority: str
    notes: str


CANDIDATES: tuple[Candidate, ...] = (
    Candidate(
        "candidate_01_TPL2_ON_S1P_OFF_death_receptor",
        "TPL2=ON, S1P=OFF",
        "upstream death-receptor/sphingolipid route",
        {"v_TPL2": 1, "v_S1P": 0},
        ("v_Apoptosis", "v_Caspase", "v_DISC", "v_Ceramide", "v_Fas", "v_FasL", "v_FasT", "v_sFas", "v_NFKB", "v_TPL2", "v_S1P"),
        "primary",
        "Best first multi-module candidate: non-direct, touches death-receptor, NFkB/TPL2, S1P and execution layers.",
    ),
    Candidate(
        "candidate_02_JAK_ON_PI3K_OFF_upstream_cytotoxic",
        "JAK=ON, PI3K=OFF",
        "upstream cytotoxic/survival route",
        {"v_JAK": 1, "v_PI3K": 0},
        ("v_Apoptosis", "v_Caspase", "v_BID", "v_IAP", "v_BclxL", "v_MCL1", "v_GZMB", "v_TBET", "v_JAK", "v_STAT3", "v_PI3K"),
        "primary",
        "Strong second multi-module candidate: turns on TBET/GZMB upstream while suppressing PI3K-dependent MCL1.",
    ),
    Candidate(
        "candidate_03_TBET_ON_PI3K_OFF_cytotoxic_backup",
        "TBET=ON, PI3K=OFF",
        "cytotoxic backup route",
        {"v_TBET": 1, "v_PI3K": 0},
        ("v_Apoptosis", "v_Caspase", "v_BID", "v_IAP", "v_BclxL", "v_MCL1", "v_GZMB", "v_TBET", "v_PI3K"),
        "backup",
        "Feasible but more direct than JAK=ON because TBET itself is clamped.",
    ),
    Candidate(
        "candidate_04_GZMB_ON_PI3K_OFF_direct_cytotoxic",
        "GZMB=ON, PI3K=OFF",
        "direct cytotoxic/survival fallback",
        {"v_GZMB": 1, "v_PI3K": 0},
        ("v_Apoptosis", "v_Caspase", "v_BID", "v_IAP", "v_BclxL", "v_MCL1", "v_GZMB", "v_PI3K"),
        "fallback",
        "Likely easy to certify, but close to the current GZMB/MCL1 flagship because GZMB is directly pinned.",
    ),
    Candidate(
        "candidate_05_GZMB_ON_MCL1_OFF_reference",
        "GZMB=ON, MCL1=OFF",
        "projected-kernel reference",
        {"v_GZMB": 1, "v_MCL1": 0},
        ("v_Apoptosis", "v_Caspase", "v_BID", "v_IAP", "v_BclxL", "v_GZMB", "v_MCL1"),
        "reference",
        "Calibration reference for the projected GZMB/MCL1 certificate.",
    ),
    Candidate(
        "candidate_06_Ceramide_ON_FasT_ON_death_axis_backup",
        "Ceramide=ON, FasT=ON",
        "death-axis backup route",
        {"v_Ceramide": 1, "v_FasT": 1},
        ("v_Apoptosis", "v_Caspase", "v_DISC", "v_Ceramide", "v_FasT"),
        "backup",
        "Certifies quickly but is DISC-proximal because DISC becomes forced in one step.",
    ),
    Candidate(
        "candidate_07_FasT_ON_S1P_OFF_negative_control",
        "FasT=ON, S1P=OFF",
        "under-forced death-axis control",
        {"v_FasT": 1, "v_S1P": 0},
        ("v_Apoptosis", "v_Caspase", "v_DISC", "v_Ceramide", "v_Fas", "v_FasL", "v_FasT", "v_sFas", "v_NFKB", "v_S1P"),
        "negative_control",
        "Expected to fail unless upstream NFKB/FasL is also forced.",
    ),
    Candidate(
        "candidate_08_GZMB_ON_IAP_OFF_negative_control",
        "GZMB=ON, IAP=OFF",
        "Phase-C failed primary control",
        {"v_GZMB": 1, "v_IAP": 0},
        ("v_Apoptosis", "v_Caspase", "v_BID", "v_IAP", "v_BclxL", "v_MCL1", "v_GZMB"),
        "negative_control",
        "Known Phase-C obstruction: adversarial survival ports can keep MCL1 on.",
    ),
)


def parse_bnet(path: Path) -> Dict[str, str]:
    rules: Dict[str, str] = {}
    with path.open("r", encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.lower().replace(" ", "") in {"targets,factors", "target,factor"}:
                continue
            lhs, rhs = (part.strip() for part in line.split(",", 1))
            rules[lhs] = rhs
    if not rules:
        raise RuntimeError(f"no rules found in {path}")
    return rules


def parse_partition(path: Path) -> tuple[Dict[str, str], Dict[str, int]]:
    mapping: Dict[str, str] = {}
    sizes: Dict[str, int] = {}
    with path.open("r", encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        for row in reader:
            module_id = row["module_id"]
            sizes[module_id] = int(row["node_count"])
            for node in row["nodes"].split(";"):
                mapping[node.strip()] = module_id
    return mapping, sizes


def parse_expr(expr: str, syms: Mapping[str, object]):
    return sympify(expr.replace("!", "~").replace("&", "&").replace("|", "|"), locals=syms)


def to_python_bool(expr: object) -> str:
    return str(expr).replace("~", " not ").replace("&", " and ").replace("|", " or ").strip()


def compile_bool(expr: object) -> tuple[Callable[[Mapping[str, int]], int], list[str], str]:
    src = to_python_bool(expr)
    code = compile(ast.parse(src, mode="eval"), "<projected_rule>", "eval")
    tokens = sorted({tok for tok in NAME_TOKEN.findall(src) if tok not in KEYWORDS})

    def evaluate(env: Mapping[str, int]) -> int:
        locals_env = {tok: bool(env.get(tok, 0)) for tok in tokens}
        return int(bool(eval(code, {"__builtins__": {}}, locals_env)))

    return evaluate, tokens, src


def build_simplified_projected_rules(rules: Mapping[str, str], candidate: Candidate) -> dict:
    all_names = sorted(set(rules) | {tok for expr in rules.values() for tok in NAME_TOKEN.findall(expr)})
    syms = {name: symbols(name) for name in all_names}
    exprs = {name: parse_expr(expr, syms) for name, expr in rules.items()}
    state_vars = [node for node in dict.fromkeys(candidate.retained) if node not in candidate.clamps]
    if TARGET not in state_vars:
        state_vars = [TARGET] + state_vars

    substitutions = {syms[TARGET]: False}
    for node, value in candidate.clamps.items():
        substitutions[syms[node]] = bool(value)

    funcs: Dict[str, Callable[[Mapping[str, int]], int]] = {}
    tokens: set[str] = set()
    simplified_rules: Dict[str, str] = {}
    dependencies: Dict[str, list[str]] = {}
    for node in state_vars:
        expr = simplify_logic(exprs[node].subs(substitutions), form="dnf")
        func, node_tokens, src = compile_bool(expr)
        funcs[node] = func
        tokens.update(node_tokens)
        simplified_rules[node] = src
        dependencies[node] = node_tokens

    ports = sorted(tok for tok in tokens if tok not in state_vars and tok not in candidate.clamps)
    return {
        "state_variables": state_vars,
        "ports": ports,
        "functions": funcs,
        "simplified_rules": simplified_rules,
        "dependencies": dependencies,
    }


def demonic_hitting_times(projected: Mapping[str, object], candidate: Candidate) -> dict:
    state_vars = list(projected["state_variables"])
    ports = list(projected["ports"])
    funcs: Mapping[str, Callable[[Mapping[str, int]], int]] = projected["functions"]  # type: ignore[assignment]
    idx = {node: i for i, node in enumerate(state_vars)}
    states = list(product((0, 1), repeat=len(state_vars)))
    port_values = list(product((0, 1), repeat=len(ports)))

    def is_target(state: tuple[int, ...]) -> bool:
        return state[idx[TARGET]] == 1

    successor_cache: Dict[tuple[int, ...], set[tuple[int, ...]]] = {}

    def successors(state: tuple[int, ...]) -> set[tuple[int, ...]]:
        if is_target(state):
            return {state}
        if state in successor_cache:
            return successor_cache[state]
        base_env = {node: state[idx[node]] for node in state_vars}
        base_env.update(candidate.clamps)
        base_env[TARGET] = 0
        out: set[tuple[int, ...]] = set()
        for vals in port_values:
            env = dict(base_env)
            env.update({port: vals[i] for i, port in enumerate(ports)})
            out.add(tuple(funcs[node](env) for node in state_vars))
        successor_cache[state] = out
        return out

    H: Dict[tuple[int, ...], int | None] = {state: (0 if is_target(state) else None) for state in states}
    changed = True
    while changed:
        changed = False
        for state in states:
            if H[state] is not None:
                continue
            succ = successors(state)
            if all(H.get(next_state) is not None for next_state in succ):
                H[state] = 1 + max(int(H[next_state]) for next_state in succ)
                changed = True

    unresolved = [state for state, value in H.items() if value is None]
    witness = None
    if unresolved:
        state = unresolved[0]
        succ = sorted(successors(state))
        witness = {
            "state": dict(zip(state_vars, state)),
            "successor_count": len(succ),
            "sample_successors": [dict(zip(state_vars, s)) for s in succ[:8]],
        }

    hitting_rows = [
        {**dict(zip(state_vars, state)), "H_projected": ("NA" if H[state] is None else int(H[state]))}
        for state in states
    ]
    return {
        "finite": not unresolved,
        "max_hitting_time": None if unresolved else max(int(v) for v in H.values() if v is not None),
        "state_count": len(states),
        "non_target_state_count": sum(1 for state in states if not is_target(state)),
        "port_cover_transition_rows": len(port_values) * sum(1 for state in states if not is_target(state)),
        "unresolved_count": len(unresolved),
        "witness": witness,
        "hitting_rows": hitting_rows,
    }


def fixed_point_witness(rules: Mapping[str, str], candidate: Candidate) -> dict:
    all_names = sorted(set(rules) | {tok for expr in rules.values() for tok in NAME_TOKEN.findall(expr)})
    syms = {name: symbols(name) for name in all_names}
    exprs = {name: parse_expr(expr, syms) for name, expr in rules.items()}
    constraints = [Not(syms[TARGET])]
    for node in rules:
        if node in candidate.clamps:
            constraints.append(syms[node] if candidate.clamps[node] else Not(syms[node]))
        else:
            constraints.append(Equivalent(syms[node], exprs[node]))
    result = satisfiable(And(*constraints), algorithm="dpll2")
    if result is False:
        return {"exists": False, "assignment": None}
    # Report a compact, biologically relevant slice plus all externally free inputs.
    relevant = [
        "v_Apoptosis", "v_Caspase", "v_BID", "v_IAP", "v_BclxL", "v_MCL1", "v_GZMB", "v_DISC",
        "v_Ceramide", "v_FasT", "v_Fas", "v_NFKB", "v_TPL2", "v_S1P", "v_JAK", "v_PI3K", "v_TBET",
        "v_STAT3", "v_IL2RB", "v_TAX", "v_PDGF", "v_Stimuli", "v_IL15", "v_CD45", "v_Stimuli2",
    ]
    assignment = {node: int(bool(result.get(syms[node], False))) for node in relevant if node in syms}
    return {"exists": True, "assignment": assignment}


def modules_for(nodes: Iterable[str], module_of: Mapping[str, str]) -> list[str]:
    return sorted({module_of.get(node, "EXTERNAL_OR_PORT") for node in nodes})


def classify(candidate: Candidate, screen: Mapping[str, object], fp: Mapping[str, object], active_module_count: int) -> tuple[str, str]:
    finite = bool(screen["finite"])
    fp_exists = bool(fp["exists"])
    priority = candidate.priority
    if finite and not fp_exists and active_module_count >= 3 and priority == "primary":
        return "PROMOTE_TO_PRIMARY", "Build relation-specific multi-module LP generator and attempt active supply compensation."
    if finite and not fp_exists and active_module_count >= 3 and priority in {"backup", "fallback"}:
        return "KEEP_AS_BACKUP", "Use only if primary multi-module candidates fail or are too bulky."
    if finite and not fp_exists:
        return "CERTIFIED_STRUCTURAL_BUT_TOO_DIRECT_OR_SMALL", "Retained only as a calibration reference."
    if not finite or fp_exists:
        return "DO_NOT_PROMOTE", "Retain as negative-control/witness evidence; not suitable for M1 promotion."
    return "REVIEW", "Manual review required."


def write_csv(path: Path, rows: Sequence[Mapping[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields: list[str] = []
    for row in rows:
        for key in row:
            if key not in fields:
                fields.append(key)
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    default_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument("--bnet", type=Path, default=default_root / "model" / "tlgl_2011_survival_network.bnet")
    parser.add_argument("--partition", type=Path, default=default_root / "model" / "tlgl_2011_module_partition.csv")
    parser.add_argument("--outdir", type=Path, default=default_root / "results" / "rerun" / "candidate_screen")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    rules = parse_bnet(args.bnet)
    module_of, module_size = parse_partition(args.partition)
    external_inputs = sorted({tok for expr in rules.values() for tok in NAME_TOKEN.findall(expr) if tok not in rules})

    summary_rows: list[dict] = []
    simplified_rows: list[dict] = []
    witness_records: dict[str, object] = {}
    fixed_point_records: dict[str, object] = {}
    hitting_dir = args.outdir / "projected_hitting_times"
    hitting_dir.mkdir(parents=True, exist_ok=True)

    for candidate in CANDIDATES:
        projected = build_simplified_projected_rules(rules, candidate)
        hit = demonic_hitting_times(projected, candidate)
        fp = fixed_point_witness(rules, candidate)
        state_vars = list(projected["state_variables"])
        ports = list(projected["ports"])
        retained_modules = modules_for(state_vars, module_of)
        clamp_modules = modules_for(candidate.clamps, module_of)
        port_modules = modules_for(ports, module_of)
        active_modules = modules_for(list(state_vars) + list(candidate.clamps), module_of)
        product_exp = sum(module_size[m] for m in active_modules if m in module_size)
        local_state_sum = sum(2 ** module_size[m] for m in active_modules if m in module_size)
        recommendation, next_action = classify(candidate, hit, fp, len(active_modules))

        row = {
            "candidate_id": candidate.candidate_id,
            "intervention": candidate.intervention_label,
            "route": candidate.route_label,
            "priority": candidate.priority,
            "projected_finite": int(bool(hit["finite"])),
            "projected_bound": "NA" if hit["max_hitting_time"] is None else int(hit["max_hitting_time"]),
            "state_variable_count": len(state_vars),
            "state_count": hit["state_count"],
            "non_target_state_count": hit["non_target_state_count"],
            "port_count": len(ports),
            "port_cover_transition_rows": hit["port_cover_transition_rows"],
            "unresolved_projected_states": hit["unresolved_count"],
            "full_bnet_non_target_fixed_point_exists": int(bool(fp["exists"])),
            "retained_or_clamped_module_count": len(active_modules),
            "original_module_product_exponent": product_exp,
            "original_module_product_state_count": f"2^{product_exp}",
            "sum_local_original_module_states": local_state_sum,
            "retained_modules": ";".join(retained_modules),
            "clamp_modules": ";".join(clamp_modules),
            "port_modules": ";".join(port_modules),
            "state_variables": ";".join(state_vars),
            "universal_ports": ";".join(ports),
            "recommendation": recommendation,
            "recommended_next_action": next_action,
            "notes": candidate.notes,
        }
        summary_rows.append(row)

        for node, rule in projected["simplified_rules"].items():
            simplified_rows.append({
                "candidate_id": candidate.candidate_id,
                "intervention": candidate.intervention_label,
                "node": node,
                "non_target_simplified_update": rule,
                "dependencies_after_simplification": ";".join(projected["dependencies"][node]),
            })
        if hit["witness"] is not None:
            witness_records[candidate.candidate_id] = hit["witness"]
        fixed_point_records[candidate.candidate_id] = fp
        write_csv(hitting_dir / f"{candidate.candidate_id}_hitting_times.csv", hit["hitting_rows"])

    promoted = [row for row in summary_rows if row["recommendation"] == "PROMOTE_TO_PRIMARY"]
    report = {
        "pass": True,
        "model_variables": len(rules),
        "external_inputs": external_inputs,
        "candidate_count": len(CANDIDATES),
        "primary_promoted_candidates": [row["candidate_id"] for row in promoted],
        "summary": summary_rows,
        "scope_note": "The candidate screen is a prefilter only. It proves finite reachability on conservative projected kernels and checks fixed-point blockers, but it does not solve a multi-module storage/supply LP or prove active supply compensation.",
    }

    write_csv(args.outdir / "candidate_screening_summary.csv", summary_rows)
    write_csv(args.outdir / "candidate_simplified_rules.csv", simplified_rows)
    (args.outdir / "candidate_projected_witnesses.json").write_text(json.dumps(witness_records, indent=2, sort_keys=True), encoding="utf-8")
    (args.outdir / "candidate_fixed_point_witnesses.json").write_text(json.dumps(fixed_point_records, indent=2, sort_keys=True), encoding="utf-8")
    (args.outdir / "candidate_screening_summary.json").write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")

    print(json.dumps({
        "pass": True,
        "candidate_count": len(CANDIDATES),
        "promote_to_candidate_primary": [row["candidate_id"] for row in promoted],
        "finite_projected_candidates": [row["candidate_id"] for row in summary_rows if row["projected_finite"]],
        "negative_controls": [row["candidate_id"] for row in summary_rows if row["recommendation"] == "DO_NOT_PROMOTE"],
        "outdir": str(args.outdir),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
