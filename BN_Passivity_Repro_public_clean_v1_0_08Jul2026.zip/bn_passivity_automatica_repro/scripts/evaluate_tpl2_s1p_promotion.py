#!/usr/bin/env python3
"""TPL2/S1P promotion evaluator for optional many-module active-composition candidates.

This script provides an optional promotion check rather than a primary paper claim.  It reads the
frozen multi-module LP outputs, applies stricter promotion criteria, checks
whether each intervention clamp is syntactically load-bearing in the projected
rule closure, and writes a reproducible promotion decision matrix.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from copy import deepcopy
from pathlib import Path
from typing import Any, Mapping, Sequence

import solve_multimodule_lp as multimodule_lp

DEFAULT_MULTIMODULE_OUTDIR = Path("results/reference/multimodule_lp")
DEFAULT_CONFIG = Path("configs/multimodule_certificate_candidates.json")
DEFAULT_OUTDIR = Path("results/rerun/tpl2_s1p_promotion")


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]], fieldnames: Sequence[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        keys: list[str] = []
        for row in rows:
            for key in row.keys():
                if key not in keys:
                    keys.append(key)
        fieldnames = keys
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})


def jsonable(x: Any) -> Any:
    if isinstance(x, dict):
        return {str(k): jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [jsonable(v) for v in x]
    return x


def load_rows(summary_path: Path) -> list[dict[str, Any]]:
    rows = json.loads(summary_path.read_text(encoding="utf-8"))
    return [dict(row) for row in rows]


def clamp_load_bearing(
    candidate: Mapping[str, Any],
    rules: Mapping[str, str],
    target: str,
) -> list[dict[str, Any]]:
    """Check whether each clamp changes the projected rule closure.

    This is a syntactic closure check, not another LP solve.  A clamp is marked
    load-bearing when omitting it changes at least one common simplified rule, or
    when the unclamped variable becomes an explicit state/context dependency in
    the ablated projection.  The check prevents artificial module-count inflation
    by irrelevant clamps.
    """
    full = multimodule_lp.simplify_candidate_rules(rules, candidate, target)
    full_rules = dict(full["simplified_rules"])
    out: list[dict[str, Any]] = []
    for clamp, value in sorted(candidate.get("clamps", {}).items()):
        ablated = deepcopy(candidate)
        ablated_clamps = dict(ablated.get("clamps", {}))
        ablated_clamps.pop(clamp, None)
        ablated["clamps"] = ablated_clamps
        try:
            ab = multimodule_lp.simplify_candidate_rules(rules, ablated, target)
            ab_rules = dict(ab["simplified_rules"])
            common = sorted(set(full_rules) & set(ab_rules))
            changed = [node for node in common if full_rules[node] != ab_rules[node]]
            appears_as_state = clamp in set(ab.get("state_variables", []))
            appears_as_port = clamp in set(ab.get("ports", []))
            appears_in_deps = any(clamp in deps for deps in ab.get("dependencies", {}).values())
            load_bearing = bool(changed or appears_as_state or appears_as_port or appears_in_deps)
            out.append({
                "candidate_id": candidate["candidate_id"],
                "clamp": clamp,
                "clamp_value": value,
                "load_bearing": load_bearing,
                "changed_common_rules": ";".join(changed[:12]),
                "changed_rule_count": len(changed),
                "appears_as_state_when_unclamped": appears_as_state,
                "appears_as_port_when_unclamped": appears_as_port,
                "appears_in_dependencies_when_unclamped": appears_in_deps,
                "ablation_status": "checked",
            })
        except Exception as exc:  # pragma: no cover - diagnostic path
            out.append({
                "candidate_id": candidate["candidate_id"],
                "clamp": clamp,
                "clamp_value": value,
                "load_bearing": True,
                "changed_common_rules": "",
                "changed_rule_count": "",
                "appears_as_state_when_unclamped": "",
                "appears_as_port_when_unclamped": "",
                "appears_in_dependencies_when_unclamped": "",
                "ablation_status": f"conservative_error:{type(exc).__name__}:{exc}",
            })
    return out


def boolify(x: Any) -> bool:
    return bool(x) and str(x).lower() not in {"false", "0", "none", "nan"}


def evaluate_row(row: Mapping[str, Any], load_rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    exact = row.get("exact_projected_bound")
    bound = row.get("lp_bound")
    exact_finite = exact is not None
    lp_finite = bound is not None
    slack = None
    stretch = None
    if exact_finite and lp_finite:
        slack = float(bound) - float(exact)
        stretch = float(bound) / max(float(exact), 1.0)
    all_clamps_load_bearing = all(boolify(r.get("load_bearing")) for r in load_rows) if load_rows else True
    not_direct_or_reference = row.get("priority") not in {"reference", "fallback"}
    structural_gate = (
        int(row.get("active_original_module_count") or 0) >= 3
        and int(row.get("module_count_projected") or 0) >= 3
        and int(row.get("original_module_product_exponent") or 0) >= 25
        and not_direct_or_reference
        and all_clamps_load_bearing
    )
    certificate_gate = (
        boolify(row.get("lp_success"))
        and exact_finite
        and int(row.get("unresolved_state_count") or 0) == 0
        and lp_finite
        and float(bound) >= float(exact)
        and int(row.get("compensated_positive_supply_port_count") or 0) > 0
        and float(row.get("min_port_slack") or 0.0) >= -1e-7
    )
    manageable_gate = (
        int(row.get("port_cover_count") or 0) <= 200000
        and int(row.get("inequality_count") or 0) <= 200000
        and int(row.get("variable_count") or 0) <= 10000
    )
    # A compact paper case-study row should have a clean bound, not merely feasibility.
    clean_bound_gate = slack is not None and slack <= 2.0 and stretch is not None and stretch <= 1.5
    d4_primary = bool(structural_gate and certificate_gate and manageable_gate and clean_bound_gate and row.get("priority") == "primary")
    d4_reserve = bool(structural_gate and certificate_gate and manageable_gate and not d4_primary)
    if d4_primary:
        decision = "PROMOTE_TO_D4_PRIMARY"
    elif d4_reserve:
        decision = "RESERVE_NOT_PRIMARY"
    elif certificate_gate:
        decision = "LP_FEASIBLE_BUT_NOT_PROMOTABLE"
    else:
        decision = "DO_NOT_PROMOTE"
    return {
        "candidate_id": row.get("candidate_id"),
        "label": row.get("label"),
        "priority": row.get("priority"),
        "route": row.get("route"),
        "active_original_module_count": row.get("active_original_module_count"),
        "projected_module_count": row.get("module_count_projected"),
        "original_module_product_exponent": row.get("original_module_product_exponent"),
        "state_variable_count": row.get("state_variable_count"),
        "universal_port_count": row.get("universal_port_count"),
        "port_cover_count": row.get("port_cover_count"),
        "variable_count": row.get("variable_count"),
        "inequality_count": row.get("inequality_count"),
        "local_edge_count": row.get("local_edge_count"),
        "local_edge_inequality_count": row.get("local_edge_inequality_count"),
        "port_inequality_count": row.get("port_inequality_count"),
        "storage_bound_inequality_count": row.get("storage_bound_inequality_count"),
        "storage_variable_count": row.get("storage_variable_count"),
        "supply_variable_count": row.get("supply_variable_count"),
        "bound_variable_count": row.get("bound_variable_count"),
        "exact_projected_bound": exact,
        "lp_bound": bound,
        "lp_minus_exact_slack": slack,
        "lp_over_exact_stretch": stretch,
        "tight_port_count": row.get("tight_port_count"),
        "compensated_positive_supply_port_count": row.get("compensated_positive_supply_port_count"),
        "all_clamps_load_bearing": all_clamps_load_bearing,
        "structural_gate": structural_gate,
        "certificate_gate": certificate_gate,
        "manageable_gate": manageable_gate,
        "clean_bound_gate": clean_bound_gate,
        "d4_primary_promotable": d4_primary,
        "d4_reserve": d4_reserve,
        "decision": decision,
    }


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--multimodule-outdir", type=Path, default=DEFAULT_MULTIMODULE_OUTDIR)
    parser.add_argument("--outdir", type=Path, default=DEFAULT_OUTDIR)
    args = parser.parse_args(argv)
    root = Path.cwd()
    config = args.config if args.config.is_absolute() else root / args.config
    multimodule_outdir = args.multimodule_outdir if args.multimodule_outdir.is_absolute() else root / args.multimodule_outdir
    outdir = args.outdir if args.outdir.is_absolute() else root / args.outdir
    outdir.mkdir(parents=True, exist_ok=True)

    cfg = json.loads(config.read_text(encoding="utf-8"))
    rows = load_rows(multimodule_outdir / "multimodule_lp_summary.json")
    candidates = {c["candidate_id"]: c for c in cfg["candidates"]}
    target = cfg.get("target", "v_Apoptosis")
    model_path = root / cfg.get("model_path", "model/tlgl_2011_survival_network.bnet")
    rules = multimodule_lp.parse_bnet(model_path)

    load_detail: list[dict[str, Any]] = []
    load_by_candidate: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        cid = row["candidate_id"]
        cand = candidates.get(cid)
        if cand is None:
            continue
        detail = clamp_load_bearing(cand, rules, target)
        load_by_candidate[cid] = detail
        load_detail.extend(detail)

    eval_rows = [evaluate_row(row, load_by_candidate.get(row["candidate_id"], [])) for row in rows]
    primary = [r for r in eval_rows if r["decision"] == "PROMOTE_TO_D4_PRIMARY"]
    reserve = [r for r in eval_rows if r["decision"] == "RESERVE_NOT_PRIMARY"]
    recommendation = {
        "pass": len(primary) == 1,
        "primary_candidate": primary[0]["candidate_id"] if primary else None,
        "d4_primary_label": primary[0]["label"] if primary else None,
        "reserve_candidates": [r["candidate_id"] for r in reserve],
        "do_not_promote": [r["candidate_id"] for r in eval_rows if r["decision"] == "DO_NOT_PROMOTE"],
        "lp_feasible_but_not_promotable": [r["candidate_id"] for r in eval_rows if r["decision"] == "LP_FEASIBLE_BUT_NOT_PROMOTABLE"],
        "decision_rule": "primary requires structural gate + certificate gate + manageable size + LP-exact slack <=2 and stretch <=1.5 + primary priority",
    }
    # Include a sample active compensation row for the promoted candidate, if available.
    if primary:
        cdir = multimodule_outdir / primary[0]["candidate_id"]
        sample = cdir / "compensated_positive_supply_ports_sample.csv"
        if sample.exists():
            with sample.open("r", encoding="utf-8", newline="") as fh:
                reader = csv.DictReader(fh)
                first = next(reader, None)
            recommendation["primary_compensation_example"] = first

    (outdir / "tpl2_s1p_promotion_evaluation.json").write_text(json.dumps(jsonable(eval_rows), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    (outdir / "promotion_recommendation.json").write_text(json.dumps(jsonable(recommendation), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    write_csv(outdir / "tpl2_s1p_promotion_evaluation.csv", eval_rows)
    write_csv(outdir / "clamp_load_bearing.csv", load_detail)
    stdout = {
        "pass": bool(recommendation["pass"]),
        "primary": recommendation["primary_candidate"],
        "reserve_candidates": recommendation["reserve_candidates"],
        "evaluated_candidates": [r["candidate_id"] for r in eval_rows],
        "outdir": str(outdir),
    }
    (outdir / "stdout_summary.json").write_text(json.dumps(jsonable(stdout), indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(jsonable(stdout), indent=2, sort_keys=True))
    return 0 if stdout["pass"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
