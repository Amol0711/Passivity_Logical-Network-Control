#!/usr/bin/env python3
"""Fast release-level reproducibility checks for the simulation package.

The script combines executable checks for the main frozen GZMB/MCL1 certificate
and the projection-free chain with static checks of the promoted TPL2/S1P
reference summary, the bounded-treewidth LP-scaling ledger, and the case-study simulation evidence ledger. It intentionally avoids rerunning the heaviest multi-module LP workflow; that optional workflow is available as scripts/reproduce_multimodule_lp.sh.  The bounded-treewidth LP-scaling script can be
rerun separately with scripts/reproduce_lp_scaling_family.py.
"""
from __future__ import annotations

import argparse
import csv
import json
import subprocess
import sys
from pathlib import Path
from typing import Any


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text())
    except Exception as exc:  # pragma: no cover - release diagnostic
        raise AssertionError(f"could not read JSON {path}: {exc}") from exc


def expect_equal(errors: list[str], label: str, observed: Any, expected: Any) -> None:
    if observed != expected:
        errors.append(f"{label}: observed {observed!r}, expected {expected!r}")


def expect_true(errors: list[str], label: str, observed: Any) -> None:
    if not observed:
        errors.append(f"{label}: expected truthy value, observed {observed!r}")


def run_json(cmd: list[str], cwd: Path) -> dict[str, Any]:
    proc = subprocess.run(cmd, cwd=str(cwd), check=False, text=True, capture_output=True)
    if proc.returncode != 0:
        raise AssertionError(
            "command failed with exit code {}\nCOMMAND: {}\nSTDOUT:\n{}\nSTDERR:\n{}".format(
                proc.returncode, " ".join(cmd), proc.stdout, proc.stderr
            )
        )
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        raise AssertionError(
            "command did not emit JSON\nCOMMAND: {}\nSTDOUT:\n{}\nSTDERR:\n{}".format(
                " ".join(cmd), proc.stdout, proc.stderr
            )
        ) from exc


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--outdir", type=Path, default=None)
    parser.add_argument("--skip-executable", action="store_true", help="Only check frozen JSON/CSV ledgers.")
    args = parser.parse_args()

    root = args.root.resolve()
    outdir = args.outdir or root / "results" / "rerun" / "quick_release"
    if not args.skip_executable:
        outdir.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []

    required = [
        root / "data" / "certificate_summary.json",
        root / "model" / "tlgl_2011_survival_network.bnet",
        root / "results" / "reference" / "multimodule_lp" / "tpl2_s1p_projected_gate" / "candidate_summary.json",
        root / "results" / "reference" / "tpl2_s1p_promotion" / "promotion_recommendation.json",
        root / "results" / "reference" / "chain_benchmark" / "compensation_chain_summary.json",
        root / "results" / "reference" / "lp_scaling_family" / "lp_scaling_family_summary.json",
        root / "results" / "reference" / "case_study_claims" / "case_study_claims.json",
    ]
    for path in required:
        if not path.exists():
            errors.append(f"missing required artifact: {path.relative_to(root)}")

    cert = load_json(root / "data" / "certificate_summary.json")
    lp = cert.get("lp_summary", {})
    expect_equal(errors, "GZMB/MCL1 model_variables", cert.get("model_variables"), 54)
    expect_equal(errors, "GZMB/MCL1 external_inputs", cert.get("model_external_inputs"), 6)
    expect_equal(errors, "GZMB/MCL1 fixed-input state count", cert.get("full_fixed_input_state_count"), 2**54)
    expect_equal(errors, "GZMB/MCL1 local_edge_count", lp.get("local_edge_count"), 48)
    expect_equal(errors, "GZMB/MCL1 port_cover_count", lp.get("port_cover_count"), 64)
    expect_equal(errors, "GZMB/MCL1 variable_count", lp.get("variable_count"), 109)
    expect_equal(errors, "GZMB/MCL1 inequality_count", lp.get("inequality_count"), 128)
    expect_equal(errors, "GZMB/MCL1 certified bound", lp.get("objective_bound"), 7.0)
    expect_equal(errors, "GZMB/MCL1 exact projected bound", cert.get("exact_kernel_max_hitting_time"), 5)
    expect_equal(errors, "GZMB/MCL1 compensated ports", lp.get("compensated_positive_supply_ports"), 6)
    expect_equal(errors, "GZMB/IAP failure candidate", cert.get("failed_primary_candidate", {}).get("candidate"), "GZMB=ON, IAP=OFF")

    tpl2 = load_json(root / "results" / "reference" / "multimodule_lp" / "tpl2_s1p_projected_gate" / "candidate_summary.json")
    expect_true(errors, "TPL2/S1P lp_success", tpl2.get("lp_success"))
    expect_equal(errors, "TPL2/S1P state_variable_count", tpl2.get("state_variable_count"), 9)
    expect_equal(errors, "TPL2/S1P universal_port_count", tpl2.get("universal_port_count"), 9)
    expect_equal(errors, "TPL2/S1P active_original_module_count", tpl2.get("active_original_module_count"), 4)
    expect_equal(errors, "TPL2/S1P original_module_product_exponent", tpl2.get("original_module_product_exponent"), 30)
    expect_equal(errors, "TPL2/S1P module_count_projected", tpl2.get("module_count_projected"), 3)
    expect_equal(errors, "TPL2/S1P variable_count", tpl2.get("variable_count"), 4233)
    expect_equal(errors, "TPL2/S1P inequality_count", tpl2.get("inequality_count"), 135490)
    expect_equal(errors, "TPL2/S1P port_cover_count", tpl2.get("port_cover_count"), 131072)
    expect_equal(errors, "TPL2/S1P lp_bound", tpl2.get("lp_bound"), 8.0)
    expect_equal(errors, "TPL2/S1P exact_projected_bound", tpl2.get("exact_projected_bound"), 7)
    expect_equal(errors, "TPL2/S1P compensated ports", tpl2.get("compensated_positive_supply_port_count"), 46080)

    promotion = load_json(root / "results" / "reference" / "tpl2_s1p_promotion" / "promotion_recommendation.json")
    expect_true(errors, "TPL2/S1P promotion recommendation pass", promotion.get("pass"))
    expect_equal(errors, "TPL2/S1P primary candidate", promotion.get("primary_candidate"), "tpl2_s1p_projected_gate")

    chain_ref = load_json(root / "results" / "reference" / "chain_benchmark" / "compensation_chain_summary.json")
    expect_equal(errors, "chain K values", [r.get("K") for r in chain_ref], [4, 16, 64, 256])
    expect_equal(errors, "chain max product states", chain_ref[-1].get("product_states"), "2^1280")
    expect_equal(errors, "chain K=256 bound", chain_ref[-1].get("certified_bound"), 5 * 256 * 256)
    expect_true(errors, "all chain reference rows pass", all(r.get("pass") for r in chain_ref))

    scaling_ref = load_json(root / "results" / "reference" / "lp_scaling_family" / "lp_scaling_family_summary.json")
    expect_equal(errors, "LP-scaling K values", [r.get("K") for r in scaling_ref], [8, 16, 32, 64, 128, 256, 512])
    expect_equal(errors, "LP-scaling max product states", scaling_ref[-1].get("product_states"), "2^2560")
    expect_equal(errors, "LP-scaling max variables", scaling_ref[-1].get("lp_variables"), 18433)
    expect_equal(errors, "LP-scaling max generated cuts", scaling_ref[-1].get("generated_port_cuts"), 513)
    expect_equal(errors, "LP-scaling max certified bound", scaling_ref[-1].get("certified_bound"), 512)
    expect_equal(errors, "LP-scaling final port violation", scaling_ref[-1].get("final_max_port_violation"), 0.0)
    expect_equal(errors, "LP-scaling final local violation", scaling_ref[-1].get("max_local_dissipation_violation"), 0.0)
    expect_equal(errors, "LP-scaling final storage-bound violation", scaling_ref[-1].get("max_storage_bound_violation"), 0.0)
    expect_true(errors, "all LP-scaling reference rows pass", all(r.get("pass") for r in scaling_ref))

    ledger = load_json(root / "results" / "reference" / "case_study_claims" / "case_study_claims.json")
    rows = {r["id"]: r for r in ledger.get("rows", [])}
    for key in [
        "gzmb_mcl1_projected_certificate",
        "tpl2_s1p_promoted_gate",
        "projection_free_chain",
        "bounded_treewidth_lp_search_scaling",
        "disc_monotone_kernel_audit",
        "four_level_cascade_exact_bracketing",
        "three_bit_conservatism_witness",
        "reduced_tlgl_anchor",
    ]:
        expect_true(errors, f"ledger row {key}", key in rows)
    if "disc_monotone_kernel_audit" in rows:
        expect_equal(errors, "DISC kernel-advancing bound", rows["disc_monotone_kernel_audit"].get("bound_kernel_advancing_steps"), 3)
        expect_equal(errors, "DISC raw tick bound flag", rows["disc_monotone_kernel_audit"].get("raw_asynchronous_tick_bound_claimed"), False)
    if "four_level_cascade_exact_bracketing" in rows:
        expect_equal(errors, "cascade exact worst case", rows["four_level_cascade_exact_bracketing"].get("exact_worst_case"), 24)
        expect_equal(errors, "cascade additive worst case", rows["four_level_cascade_exact_bracketing"].get("additive_worst_case"), 24)
    if "three_bit_conservatism_witness" in rows:
        expect_equal(errors, "three-bit exact worst case", rows["three_bit_conservatism_witness"].get("exact_worst_case"), 3)
        expect_equal(errors, "three-bit singleton infeasible", rows["three_bit_conservatism_witness"].get("singleton_additive_storage_feasible"), False)
    if "reduced_tlgl_anchor" in rows:
        bounds = rows["reduced_tlgl_anchor"].get("intervention_bounds", {})
        expect_equal(errors, "reduced S1P=OFF bound", bounds.get("S1P=OFF"), 5)
        expect_equal(errors, "reduced Ceramide=ON bound", bounds.get("Ceramide=ON"), 3)
        expect_equal(errors, "reduced DISC=ON bound", bounds.get("DISC=ON"), 2)
        expect_equal(errors, "reduced DISC_feedback bound", bounds.get("DISC_feedback"), 2)

    executable = {}
    if not args.skip_executable:
        try:
            executable["gzmb_mcl1"] = run_json(
                [
                    sys.executable,
                    str(root / "scripts" / "verify_gzmb_mcl1_certificate.py"),
                    "--data",
                    str(root / "data"),
                    "--outdir",
                    str(outdir / "gzmb_mcl1"),
                ],
                root,
            )
            expect_true(errors, "executable GZMB/MCL1 verifier", executable["gzmb_mcl1"].get("pass"))
        except Exception as exc:
            errors.append(f"executable GZMB/MCL1 verifier failed: {exc}")
        try:
            executable["chain"] = run_json(
                [
                    sys.executable,
                    str(root / "scripts" / "verify_compensation_chain.py"),
                    "--outdir",
                    str(outdir / "chain"),
                    "--reference",
                    str(root / "results" / "reference" / "chain_benchmark" / "compensation_chain_summary.json"),
                ],
                root,
            )
            expect_true(errors, "executable chain verifier", executable["chain"].get("pass"))
        except Exception as exc:
            errors.append(f"executable chain verifier failed: {exc}")
        try:
            executable["lp_scaling_small"] = run_json(
                [
                    sys.executable,
                    str(root / "scripts" / "reproduce_lp_scaling_family.py"),
                    "--ks",
                    "8,16,32",
                    "--outdir",
                    str(outdir / "lp_scaling_small"),
                ],
                root,
            )
            expect_true(errors, "executable LP-scaling small verifier", executable["lp_scaling_small"].get("pass"))
        except Exception as exc:
            errors.append(f"executable LP-scaling small verifier failed: {exc}")

    summary = {
        "pass": not errors,
        "errors": errors,
        "root": str(root),
        "release_id": ledger.get("release_id"),
        "package_version": ledger.get("package_version"),
        "checks": {
            "required_artifacts": len(required),
            "gzmb_mcl1_reference": {
                "model_variables": cert.get("model_variables"),
                "fixed_input_state_count": cert.get("full_fixed_input_state_count"),
                "certified_bound": lp.get("objective_bound"),
                "exact_projected_bound": cert.get("exact_kernel_max_hitting_time"),
            },
            "tpl2_s1p_reference": {
                "variable_count": tpl2.get("variable_count"),
                "inequality_count": tpl2.get("inequality_count"),
                "port_cover_count": tpl2.get("port_cover_count"),
                "certified_bound": tpl2.get("lp_bound"),
                "exact_projected_bound": tpl2.get("exact_projected_bound"),
            },
            "chain_reference": {
                "K_values": [r.get("K") for r in chain_ref],
                "max_product_states": chain_ref[-1].get("product_states"),
            },
            "lp_scaling_reference": {
                "K_values": [r.get("K") for r in scaling_ref],
                "max_product_states": scaling_ref[-1].get("product_states"),
                "max_lp_variables": scaling_ref[-1].get("lp_variables"),
                "max_generated_cuts": scaling_ref[-1].get("generated_port_cuts"),
            },
            "ledger_rows": sorted(rows),
            "executable_checks_ran": not args.skip_executable,
        },
    }
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
