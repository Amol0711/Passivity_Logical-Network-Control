#!/usr/bin/env python3
"""Verify the frozen GZMB/MCL1 projected-kernel certificate.

This checker uses only the Python standard library. It reads the bundled BNET,
storage table, port-supply table, and kernel hitting-time table, then verifies:
  1. source-rule implications for the projected kernel;
  2. Apoptosis target invariance A+ = A or C;
  3. all local execution/survival storage inequalities;
  4. all port inequalities sigma_E + sigma_S <= -1 outside target;
  5. the additive bound max(V_E+V_S) <= 7 outside target;
  6. exact demonic-port kernel hitting times and maximum 5.
It does not enumerate the 2^54 full state graph.
"""
from __future__ import annotations

import argparse
import ast
import csv
import json
import re
from itertools import product
from pathlib import Path
from typing import Dict, Iterable, Mapping, Tuple

NAME_TOKEN = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]*\b")
KEYWORDS = {"and", "or", "not", "True", "False"}
TOL = 1e-8


def normalize_expr(expr: str) -> str:
    return expr.replace("!", " not ").replace("&", " and ").replace("|", " or ").strip()


def eval_bool(expr: str, env: Mapping[str, int | bool]) -> int:
    parsed = ast.parse(normalize_expr(expr), mode="eval")
    return int(bool(eval(compile(parsed, "<bnet>", "eval"), {"__builtins__": {}}, {k: bool(v) for k, v in env.items()})))


def parse_bnet(path: Path) -> Dict[str, str]:
    rules: Dict[str, str] = {}
    with path.open("r", encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.lower().replace(" ", "") in {"targets,factors", "target,factor"}:
                continue
            lhs, rhs = (part.strip() for part in line.split(",", 1))
            rules[lhs] = rhs
    return rules


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def combo_kernel_next(A: int, C: int, B: int, I: int, L: int, N: int, D: int) -> Tuple[int, int, int, int, int]:
    Ap = int(A or C)
    Cp = int(D or (B and not I)) if A == 0 else int(A or C)
    Bp = int((not L) and (not A))
    Ip = int(N and not (B or A))
    Lp = 0
    return Ap, Cp, Bp, Ip, Lp


def exact_kernel_hitting_times() -> Dict[Tuple[int, int, int, int, int], int]:
    states = list(product((0, 1), repeat=5))
    H: Dict[Tuple[int, int, int, int, int], int | None] = {tuple(s): (0 if s[0] == 1 else None) for s in states}
    changed = True
    while changed:
        changed = False
        for s in states:
            s = tuple(s)
            if H[s] is not None:
                continue
            succ = {combo_kernel_next(*s, N, D) for N, D in product((0, 1), repeat=2)}
            if all(H[sp] is not None for sp in succ):
                H[s] = 1 + max(int(H[sp]) for sp in succ)
                changed = True
    missing = [s for s, v in H.items() if v is None]
    if missing:
        raise AssertionError(f"non-reaching kernel states: {missing}")
    return {s: int(v) for s, v in H.items()}


def load_storage(data: Path) -> tuple[dict[tuple[int, int, int], float], dict[tuple[int, int], float]]:
    VE: dict[tuple[int, int, int], float] = {}
    VS: dict[tuple[int, int], float] = {}
    for row in read_csv(data / "storage_values.csv"):
        state = row["state"]
        val = float(row["storage"])
        if row["module"] == "execution":
            # State format A0C0B0.
            VE[(int(state[1]), int(state[3]), int(state[5]))] = val
        elif row["module"] == "survival":
            # State format I0L0.
            VS[(int(state[1]), int(state[3]))] = val
    return VE, VS


def load_ports(data: Path) -> tuple[dict[tuple[int, int, int, int, int, int], float], dict[tuple[int, int, int, int, int], float], list[dict[str, str]]]:
    SE: dict[tuple[int, int, int, int, int, int], float] = {}
    SS: dict[tuple[int, int, int, int, int], float] = {}
    rows = read_csv(data / "all_port_inequalities.csv")
    for r in rows:
        A, C, B, I, L, N, D = (int(r[k]) for k in ["A", "C", "BID", "IAP", "BclxL", "NFKB", "DISC"])
        SE[(A, C, B, I, L, D)] = float(r["sigma_execution"])
        SS[(I, L, A, B, N)] = float(r["sigma_survival"])
    return SE, SS, rows


def check_rule_implications(rules: Mapping[str, str]) -> list[str]:
    failures: list[str] = []
    for A, C, B, I, L, N, D, T, S in product((0, 1), repeat=9):
        env = {name: 0 for name in rules}
        env.update({"v_Apoptosis": A, "v_Caspase": C, "v_BID": B, "v_IAP": I, "v_BclxL": L,
                    "v_NFKB": N, "v_DISC": D, "v_TRADD": T, "v_STAT3": S, "v_GZMB": 1, "v_MCL1": 0})
        if eval_bool(rules["v_Apoptosis"], env) != int(A or C):
            failures.append("Apoptosis absorbing rule failed")
        if A == 0:
            expected = {
                "v_Caspase": int(D or (B and not I)),
                "v_BID": int(not L),
                "v_IAP": int(N and not B),
                "v_BclxL": 0,
            }
            for node, exp in expected.items():
                got = eval_bool(rules[node], env)
                if got != exp:
                    failures.append(f"{node} implication failed for A,C,B,I,L,N,D,T,S={(A,C,B,I,L,N,D,T,S)}: got {got}, expected {exp}")
    return failures


def verify(data: Path, bnet: Path) -> dict:
    rules = parse_bnet(bnet)
    external = sorted({tok for expr in rules.values() for tok in NAME_TOKEN.findall(expr) if tok not in rules and tok not in KEYWORDS})
    VE, VS = load_storage(data)
    SE, SS, port_rows = load_ports(data)
    failures: list[str] = []

    if len(rules) != 54:
        failures.append(f"expected 54 target rules, found {len(rules)}")
    if len(external) != 6:
        failures.append(f"expected 6 external inputs, found {len(external)}: {external}")

    failures.extend(check_rule_implications(rules))

    # Local execution inequalities.
    exec_count = 0
    for A, C, B in product((0, 1), repeat=3):
        if A == 1:
            continue
        for I, L, D in product((0, 1), repeat=3):
            Ap, Cp, Bp, _Ip, _Lp = combo_kernel_next(A, C, B, I, L, 0, D)
            dv = VE[(Ap, Cp, Bp)] - VE[(A, C, B)]
            sigma = SE[(A, C, B, I, L, D)]
            if dv - sigma > TOL:
                failures.append(f"execution inequality failed at {(A,C,B,I,L,D)}: dV={dv}, sigma={sigma}")
            exec_count += 1

    # Local survival inequalities.
    surv_count = 0
    for I, L in product((0, 1), repeat=2):
        for A, B, N in product((0, 1), repeat=3):
            if A == 1:
                continue
            _Ap, _Cp, _Bp, Ip, Lp = combo_kernel_next(A, 0, B, I, L, N, 0)
            dv = VS[(Ip, Lp)] - VS[(I, L)]
            sigma = SS[(I, L, A, B, N)]
            if dv - sigma > TOL:
                failures.append(f"survival inequality failed at {(I,L,A,B,N)}: dV={dv}, sigma={sigma}")
            surv_count += 1

    # Port inequalities, tight and compensated counts.
    tight = compensated = 0
    for row in port_rows:
        A, C, B, I, L, N, D = (int(row[k]) for k in ["A", "C", "BID", "IAP", "BclxL", "NFKB", "DISC"])
        se = SE[(A, C, B, I, L, D)]
        ss = SS[(I, L, A, B, N)]
        slack = -1.0 - (se + ss)
        if slack < -TOL:
            failures.append(f"port inequality failed at {(A,C,B,I,L,N,D)}: sigma sum={se+ss}")
        if abs(slack) <= TOL:
            tight += 1
        if (se > TOL and ss < -1.0 - TOL) or (ss > TOL and se < -1.0 - TOL):
            compensated += 1

    # Additive bound.
    max_storage = max(VE[(A,C,B)] + VS[(I,L)] for A,C,B,I,L in product((0, 1), repeat=5) if A == 0)
    if max_storage - 7.0 > TOL:
        failures.append(f"additive storage bound failed: max {max_storage} > 7")

    # Hitting-time table.
    H = exact_kernel_hitting_times()
    table_H = {(int(r["A"]), int(r["C"]), int(r["BID"]), int(r["IAP"]), int(r["BclxL"])): int(r["H_kernel"]) for r in read_csv(data / "kernel_hitting_times.csv")}
    if H != table_H:
        failures.append("kernel_hitting_times.csv does not match recomputed exact demonic-port hitting times")

    expected = {
        "execution_edge_count": 32,
        "survival_edge_count": 16,
        "local_edge_count": 48,
        "port_cover_count": 64,
        "tight_port_count": 22,
        "compensated_positive_supply_ports": 6,
        "exact_kernel_max_hitting_time": 5,
        "certified_additive_bound": 7,
    }
    observed = {
        "execution_edge_count": exec_count,
        "survival_edge_count": surv_count,
        "local_edge_count": exec_count + surv_count,
        "port_cover_count": len(port_rows),
        "tight_port_count": tight,
        "compensated_positive_supply_ports": compensated,
        "exact_kernel_max_hitting_time": max(H.values()),
        "certified_additive_bound": max_storage,
    }
    for key, exp in expected.items():
        if abs(observed[key] - exp) > TOL:
            failures.append(f"{key}: expected {exp}, observed {observed[key]}")

    return {
        "pass": not failures,
        "failures": failures,
        "model_variables": len(rules),
        "external_inputs": external,
        "full_fixed_input_state_count": 2 ** len(rules),
        "full_component_input_valuation_count": 2 ** (len(rules) + len(external)),
        "observed": observed,
        "expected": expected,
        "note": "Verification enumerates the 5-bit projected kernel and port cover, not the 2^54 full product graph.",
    }


def main() -> None:
    default_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser()
    parser.add_argument("--bnet", type=Path, default=default_root / "model" / "tlgl_2011_survival_network.bnet")
    parser.add_argument("--data", type=Path, default=default_root / "data")
    parser.add_argument("--outdir", type=Path, default=default_root / "results" / "rerun" / "verify")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    report = verify(args.data, args.bnet)
    (args.outdir / "verification_report.json").write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if not report["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
