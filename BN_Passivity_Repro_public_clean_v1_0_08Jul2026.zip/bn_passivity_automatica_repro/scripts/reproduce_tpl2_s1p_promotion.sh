#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
cd "$ROOT"
RERUN_ROOT="${1:-$ROOT/results/rerun/tpl2_s1p_promotion}"
REFERENCE="$ROOT/results/reference/tpl2_s1p_promotion"
rm -rf "$RERUN_ROOT"
mkdir -p "$RERUN_ROOT"
python3 "$ROOT/scripts/evaluate_tpl2_s1p_promotion.py" \
  --multimodule-outdir "$ROOT/results/reference/multimodule_lp" \
  --outdir "$RERUN_ROOT" > "$RERUN_ROOT/stdout.json"
python3 - "$REFERENCE" "$RERUN_ROOT" <<'PY'
import json, sys
from pathlib import Path
ref=Path(sys.argv[1]); rerun=Path(sys.argv[2])
errors=[]
for name in ["tpl2_s1p_promotion_evaluation.json", "promotion_recommendation.json"]:
    r0=json.loads((ref/name).read_text())
    r1=json.loads((rerun/name).read_text())
    if r0 != r1:
        errors.append(f"{name} differs")
for name in ["tpl2_s1p_promotion_evaluation.csv", "clamp_load_bearing.csv"]:
    if (ref/name).read_text() != (rerun/name).read_text():
        errors.append(f"{name} differs")
stdout=json.loads((rerun/'stdout.json').read_text())
summary={
    'pass': not errors and bool(stdout.get('pass')),
    'primary': stdout.get('primary'),
    'reserve_candidates': stdout.get('reserve_candidates'),
    'reference': str(ref),
    'rerun': str(rerun),
    'errors': errors,
    'runtime_note': 'Promotion decisions use frozen multi-module LP summaries; LP-solve reproducibility is checked separately by reproduce_multimodule_lp.sh.'
}
print(json.dumps(summary, indent=2, sort_keys=True))
if not summary['pass']:
    raise SystemExit(1)
PY
