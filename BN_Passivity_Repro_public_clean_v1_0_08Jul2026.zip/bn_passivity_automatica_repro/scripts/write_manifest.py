#!/usr/bin/env python3
"""Write MANIFEST.tsv and SHA256SUMS.txt for shipped repository files."""
from __future__ import annotations
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE_PARTS = {'.git', '__pycache__'}
EXCLUDE_PREFIXES = [('results', 'rerun')]
EXCLUDE_NAMES = {'MANIFEST.tsv', 'SHA256SUMS.txt'}

def included(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in EXCLUDE_PARTS for part in rel.parts):
        return False
    if path.name in EXCLUDE_NAMES:
        return False
    if rel.parts[:2] in EXCLUDE_PREFIXES:
        return False
    if len(rel.parts) >= 2 and rel.parts[0] == 'results' and rel.parts[1].startswith('rerun'):
        return False
    return True

def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

rows = []
for path in sorted(p for p in ROOT.rglob('*') if p.is_file() and included(p)):
    rel = path.relative_to(ROOT).as_posix()
    rows.append((rel, path.stat().st_size, sha(path)))

(ROOT / 'MANIFEST.tsv').write_text('\n'.join(f'{rel}\t{size}\t{digest}' for rel, size, digest in rows) + '\n')
(ROOT / 'SHA256SUMS.txt').write_text('\n'.join(f'{digest}  {rel}' for rel, _size, digest in rows) + '\n')
print(f'wrote {len(rows)} files')
