#!/usr/bin/env bash
# Fast release-level reproduction entry point.
# For the heavier solver workflow included in this repository, run
# scripts/reproduce_solver_workflow.sh.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
exec bash "$ROOT/scripts/reproduce_quick.sh" "$@"
