#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
RERUN_ROOT="${1:-$ROOT/results/rerun}"
rm -rf "$RERUN_ROOT"
mkdir -p "$RERUN_ROOT"
python3 "$ROOT/scripts/verify_gzmb_mcl1_certificate.py" --data "$ROOT/data" --outdir "$RERUN_ROOT/verify_frozen" > "$RERUN_ROOT/verify_frozen_stdout.json"
python3 "$ROOT/scripts/solve_gzmb_mcl1_lp.py" --outdir "$RERUN_ROOT/solve" > "$RERUN_ROOT/solve_stdout.json"
python3 "$ROOT/scripts/verify_gzmb_mcl1_certificate.py" --data "$RERUN_ROOT/solve" --outdir "$RERUN_ROOT/verify_solve" > "$RERUN_ROOT/verify_solve_stdout.json"
python3 "$ROOT/scripts/screen_candidate_interventions.py" --outdir "$RERUN_ROOT/candidate_screen" > "$RERUN_ROOT/candidate_screen_stdout.json"
bash "$ROOT/scripts/reproduce_tpl2_s1p_promotion.sh" "$RERUN_ROOT/tpl2_s1p_promotion" > "$RERUN_ROOT/tpl2_s1p_promotion_stdout.json"
python3 "$ROOT/scripts/verify_compensation_chain.py" \
  --outdir "$RERUN_ROOT/chain_benchmark" \
  --reference "$ROOT/results/reference/chain_benchmark/compensation_chain_summary.json" \
  > "$RERUN_ROOT/chain_benchmark_stdout.json"
python3 - "$RERUN_ROOT" "$ROOT/results/reference/multimodule_lp/multimodule_lp_summary.json" <<'PY'
import json, sys
from pathlib import Path
rerun=Path(sys.argv[1]); multimodule_ref=Path(sys.argv[2])
vf=json.loads((rerun/'verify_frozen_stdout.json').read_text())
vs=json.loads((rerun/'verify_solve_stdout.json').read_text())
so=json.loads((rerun/'solve_stdout.json').read_text())
cs=json.loads((rerun/'candidate_screen_stdout.json').read_text())
promotion=json.loads((rerun/'tpl2_s1p_promotion_stdout.json').read_text())
chain=json.loads((rerun/'chain_benchmark_stdout.json').read_text())
multimodule_rows=json.loads(multimodule_ref.read_text())
multimodule_reference_pass=bool(multimodule_rows) and all(row.get('lp_success') for row in multimodule_rows)
chain_rows=chain.get('rows') or []
summary={
 'pass': bool(vf.get('pass') and vs.get('pass') and so.get('pass') and cs.get('pass') and promotion.get('pass') and chain.get('pass') and multimodule_reference_pass),
 'rerun_root': str(rerun),
 'frozen_certificate_pass': bool(vf.get('pass')),
 'solver_rerun_pass': bool(so.get('pass')),
 'solver_rerun_verified_pass': bool(vs.get('pass')),
 'candidate_screen_pass': bool(cs.get('pass')),
 'd2_reference_summary_pass': multimodule_reference_pass,
 'tpl2_s1p_promotion_pass': bool(promotion.get('pass')),
 'compensation_chain_pass': bool(chain.get('pass')),
 'stable_values': {
   'variables': so.get('variables'), 'inequalities': so.get('inequalities'), 'local_edges': so.get('local_edges'),
   'port_cover': so.get('port_cover'), 'compensated_ports': so.get('compensated_ports'),
   'kernel_exact_max': so.get('kernel_exact_max'), 'certified_bound': so.get('bound')},
 'candidate_screen': {
   'candidate_count': cs.get('candidate_count'),
   'promote_to_candidate_primary': cs.get('promote_to_candidate_primary'),
   'finite_projected_candidates': cs.get('finite_projected_candidates'),
   'negative_controls': cs.get('negative_controls')},
 'd2_reference_summary': {
   'candidate_count': len(multimodule_rows),
   'solved_candidates': [r.get('candidate_id') for r in multimodule_rows if r.get('lp_success')],
   'promotion_eligible_by_lp': [r.get('candidate_id') for r in multimodule_rows if r.get('promotion_eligible_by_lp')]},
 'tpl2_s1p_promotion': {
   'primary': promotion.get('primary'),
   'reserve_candidates': promotion.get('reserve_candidates')},
 'compensation_chain': {
   'K_values': chain.get('K_values'),
   'benchmark': chain.get('benchmark'),
   'max_reported_product_states': chain_rows[-1].get('product_states') if chain_rows else None,
   'max_reported_K': chain_rows[-1].get('K') if chain_rows else None,
   'reference_match': chain.get('reference_match')},
 'runtime_note': 'Quick workflow does not rerun the heavy multi-module LP solve; use scripts/reproduce_multimodule_lp.sh for the full multi-module LP rerun.'}
print(json.dumps(summary, indent=2, sort_keys=True))
if not summary['pass']:
    raise SystemExit(1)
PY
