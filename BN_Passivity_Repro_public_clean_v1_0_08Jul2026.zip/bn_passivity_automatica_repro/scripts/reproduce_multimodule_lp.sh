#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
cd "$ROOT"
RERUN_ROOT="${1:-$ROOT/results/rerun/multimodule_lp}"
CONFIG="${2:-$ROOT/configs/multimodule_certificate_candidates.json}"
REFERENCE="$ROOT/results/reference/multimodule_lp/multimodule_lp_summary.json"
rm -rf "$RERUN_ROOT"
mkdir -p "$RERUN_ROOT"
python3 "$ROOT/scripts/solve_multimodule_lp.py" --config "$CONFIG" --outdir "$RERUN_ROOT" > "$RERUN_ROOT/stdout.json"
python3 - "$REFERENCE" "$RERUN_ROOT/multimodule_lp_summary.json" "$RERUN_ROOT/stdout.json" <<'PY'
import json, sys
from pathlib import Path
ref_path=Path(sys.argv[1])
rerun_path=Path(sys.argv[2])
stdout_path=Path(sys.argv[3])
ref=json.loads(ref_path.read_text())
rerun=json.loads(rerun_path.read_text())
stable_keys=[
 'candidate_id','label','priority','route','state_variable_count','universal_port_count',
 'projected_state_count','non_target_state_count','transition_row_count','exact_projected_bound',
 'unresolved_state_count','module_count_projected','active_original_module_count',
 'original_module_product_exponent','lp_success','lp_bound','variable_count','inequality_count',
 'nonzero_count','local_edge_count','local_edge_inequality_count','port_cover_count',
 'port_inequality_count','storage_bound_inequality_count','storage_variable_count',
 'supply_variable_count','bound_variable_count','tight_port_count','positive_supply_port_count',
 'compensated_positive_supply_port_count',
 'promotion_eligible_by_lp','linprog_message'
]
# Float fields with solver tolerance.
float_keys={'lp_bound','min_port_slack','max_port_slack'}
errors=[]
if len(ref)!=len(rerun):
    errors.append(f'row count mismatch: reference {len(ref)} rerun {len(rerun)}')
ref_by={row['candidate_id']: row for row in ref}
rerun_by={row['candidate_id']: row for row in rerun}
for cid, r0 in ref_by.items():
    r1=rerun_by.get(cid)
    if r1 is None:
        errors.append(f'missing candidate in rerun: {cid}')
        continue
    for key in stable_keys:
        if r0.get(key)!=r1.get(key):
            errors.append(f'{cid}: {key} differs: ref={r0.get(key)!r} rerun={r1.get(key)!r}')
    for key in float_keys:
        v0=r0.get(key); v1=r1.get(key)
        if v0 is None and v1 is None:
            continue
        if v0 is None or v1 is None or abs(float(v0)-float(v1))>1e-7:
            errors.append(f'{cid}: {key} differs: ref={v0!r} rerun={v1!r}')

if not stdout_path.exists():
    alt=rerun_path.parent/'stdout_summary.json'
    if alt.exists():
        stdout_path=alt
stdout=json.loads(stdout_path.read_text())
summary={
 'pass': not errors and bool(stdout.get('pass')),
 'candidate_count': len(rerun),
 'solved_candidates': stdout.get('solved_candidates'),
 'promotion_eligible_by_lp': stdout.get('promotion_eligible_by_lp'),
 'reference': str(ref_path),
 'rerun_summary': str(rerun_path),
 'checked_keys': stable_keys + sorted(float_keys),
 'errors': errors[:20],
 'runtime_note': 'wall-clock solve times and absolute output directories are intentionally excluded from stable comparisons.'
}
print(json.dumps(summary, indent=2, sort_keys=True))
if not summary['pass']:
    raise SystemExit(1)
PY
