# Model provenance note

The bundled T-LGL rule file is:

`model/tlgl_2011_survival_network.bnet`

It is a 54-target Boolean-network record derived from the T-cell large granular lymphocyte leukemia survival-network update table of Saadatpour et al. (2011), which builds on the T-LGL survival-network model of Zhang et al. (2008). Please cite the original model sources when using or redistributing this record.

The file has:

- 54 target/update variables;
- six free/source inputs detected from rule dependencies: `v_CD45`, `v_IL15`, `v_PDGF`, `v_Stimuli`, `v_Stimuli2`, and `v_TAX`;
- the absorbing target rule `v_Apoptosis, (v_Caspase | v_Apoptosis)`.

The key source rows for the GZMB/MCL1 projected-kernel audit are:

```text
v_Apoptosis, (v_Caspase | v_Apoptosis)
v_Caspase, (((v_DISC & !v_Apoptosis) | ((v_GZMB & v_BID) & !(v_Apoptosis | v_IAP))) | ((v_TRADD & v_BID) & !(v_Apoptosis | v_IAP)))
v_BID, ((v_GZMB & !((v_BclxL | v_Apoptosis) | v_MCL1)) | (v_Caspase & !((v_BclxL | v_Apoptosis) | v_MCL1)))
v_IAP, (v_NFKB & !(v_BID | v_Apoptosis))
v_BclxL, ((v_STAT3 & !(((v_BID | v_DISC) | v_GZMB) | v_Apoptosis)) | (v_NFKB & !(((v_BID | v_DISC) | v_GZMB) | v_Apoptosis)))
```

Under `v_GZMB=1`, `v_MCL1=0`, and non-target guard `v_Apoptosis=0`, these simplify to:

```text
A+ = A or C
C+ = D or (B and not I)
B+ = not L
I+ = N and not B
L+ = 0
```

where `A=Apoptosis`, `C=Caspase`, `B=BID`, `I=IAP`, `L=BclxL`, `D=DISC`, and `N=NFKB`. `D` and `N` are internal T-LGL nodes exposed as universally quantified internal ports, not environmental inputs.
