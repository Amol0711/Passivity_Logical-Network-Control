# Reproducibility scope

This repository is an executable simulation-artifact repository. It does not include paper source, paper PDF, bibliography files, or LaTeX/TikZ figure source.

The main executable checks are the GZMB/MCL1 projected-kernel certificate, the projection-free compensation-chain benchmark, and a bounded-treewidth LP-search smoke rerun. The promoted TPL2/S1P row is provided as a frozen multi-module reference summary with optional LP-rerun scripts. DISC, cascade, three-bit, and reduced T-LGL rows are included in a case-study simulation reference ledger because they are short supporting audits rather than the principal computational bottleneck.

The package does not enumerate the full `2^54` T-LGL internal state graph. The full-model claim uses rule-level projection/lifting. Local certificates are checked on projected local edge covers and finite port covers.
