# GitHub release checklist

1. Push this repository to GitHub.
2. Run `bash scripts/reproduce_all.sh` from a clean clone.
3. Run `sha256sum -c SHA256SUMS.txt`.
4. Confirm that the repository contains no paper source files, paper PDFs, bibliography files, or LaTeX/TikZ figure sources.
5. Tag a release, preferably `v1.0.0`.
6. Optionally archive the release on Zenodo and cite the release DOI.
